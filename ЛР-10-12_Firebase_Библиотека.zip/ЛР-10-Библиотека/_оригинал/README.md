# ЛР-10 — Введение в Firebase и Firestore (вариант 1 — «Библиотека»)

## Что нужно сделать в Firebase Console (руками, до запуска страницы)

1. Создайте проект `library-ваши-инициалы` на https://console.firebase.google.com
2. Build → Firestore Database → «Создать базу» → **тестовый режим**.
3. Project settings → Your apps → добавьте веб-приложение с именем **MyLibrary**,
   скопируйте `firebaseConfig` и вставьте его в `index.html` вместо `YOUR_...`.
4. В Firestore создайте коллекцию **books** и добавьте вручную минимум 3 документа:

| title | author | year | pages | available |
|---|---|---|---|---|
| JavaScript для начинающих | Иван Петров | 2023 | 300 | true |
| Чистый код | Роберт Мартин | 2008 | 464 | false |
| Программируем на Python | Эрик Мэтиз | 2021 | 288 | true |

(поля `year` и `pages` — тип **number**, `available` — тип **boolean**)

5. Откройте `index.html` через локальный сервер (`npx serve .` или
   `python3 -m http.server 8080`) — список книг должен загрузиться с сервера.

Это базовая версия без авторизации — она дорабатывается в ЛР-11 и ЛР-12.
