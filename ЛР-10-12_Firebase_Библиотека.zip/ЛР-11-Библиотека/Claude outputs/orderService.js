import { prisma } from "../config/prisma.js";

// Заказ вместе с пользователем, позициями и товарами позиций.
export async function findOrderById(id) {
  return prisma.order.findUnique({
    where: {
      id
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true
        }
      },
      items: {
        include: {
          product: {
            select: {
              id: true,
              name: true
            }
          }
        }
      }
    }
  });
}

// Детали заказа + вычисляемое поле total.
// Сумма считается по OrderItem.price (цена на момент заказа), а не по Product.price.
export async function getOrderDetails(id) {
  const order = await findOrderById(id);

  if (!order) {
    return null;
  }

  const total = order.items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return {
    ...order,
    total
  };
}

// Relation filter some: заказы, в которых есть хотя бы одна позиция с productId.
export async function findOrdersByProduct(productId) {
  return prisma.order.findMany({
    where: {
      items: {
        some: {
          productId
        }
      }
    },
    include: {
      items: {
        include: {
          product: true
        }
      }
    },
    orderBy: {
      id: "asc"
    }
  });
}

// GET /api/orders/:id/items (из ЛР-4), теперь через Prisma вместо SQL JOIN.
// Возвращает null, если заказа нет.
export async function getOrderItems(orderId) {
  const order = await prisma.order.findUnique({
    where: {
      id: orderId
    },
    select: {
      items: {
        include: {
          product: {
            select: {
              id: true,
              name: true
            }
          }
        },
        orderBy: {
          product: {
            name: "asc"
          }
        }
      }
    }
  });

  if (!order) {
    return null;
  }

  return order.items.map((item) => ({
    id: item.product.id,
    name: item.product.name,
    quantity: item.quantity,
    price: item.price,
    lineTotal: item.quantity * item.price
  }));
}
