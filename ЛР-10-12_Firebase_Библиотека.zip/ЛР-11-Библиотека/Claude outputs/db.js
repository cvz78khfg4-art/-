import {
  loadEnvFile
} from "node:process";
import {
  Pool
} from "pg";

loadEnvFile();

export const pool = new Pool({
  host:
    process.env.PGHOST,
  port:
    Number(
      process.env.PGPORT
    ),
  database:
    process.env.PGDATABASE,
  user:
    process.env.PGUSER,
  password:
    process.env.PGPASSWORD
});
