import {
  getAllProducts,
  findProductById,
  addProduct,
  updateProductById,
  deleteProductById
} from "../services/productService.js";
import { AppError } from "../errors/AppError.js";

export async function getProducts(
  req,
  res,
  next
) {
  try {
    const products =
      await getAllProducts();

    res.json(products);
  } catch (error) {
    next(error);
  }
}

export async function getProductById(
  req,
  res,
  next
) {
  try {
    const id =
      Number(req.params.id);

    const product =
      await findProductById(id);

    if (!product) {
      return next(
        new AppError(
          "Product not found",
          404
        )
      );
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}

export async function createProduct(
  req,
  res,
  next
) {
  try {
    const product =
      await addProduct(req.body);

    res
      .status(201)
      .json(product);
  } catch (error) {
    next(error);
  }
}

export async function updateProduct(
  req,
  res,
  next
) {
  try {
    const id =
      Number(req.params.id);

    const product =
      await updateProductById(
        id,
        req.body
      );

    if (!product) {
      return next(
        new AppError(
          "Product not found",
          404
        )
      );
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}

export async function deleteProduct(
  req,
  res,
  next
) {
  try {
    const id =
      Number(req.params.id);

    const product =
      await deleteProductById(id);

    if (!product) {
      return next(
        new AppError(
          "Product not found",
          404
        )
      );
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}
