-- ЛР-3. Вынос категории в отдельную таблицу categories с переносом данных.
--   psql -h localhost -U shop_user -d shop_db -f sql/06_categories.sql
-- Ожидаемое состояние до запуска: products со столбцом category
-- (Keyboard, Mouse, Monitor, SSD 2TB).
-- Скрипт выполняется в одной транзакции: при любой ошибке структура не меняется.

\set ON_ERROR_STOP on

BEGIN;

-- 1. Текущая структура
SELECT *
FROM products
ORDER BY id;

-- 2. Уникальные категории
SELECT DISTINCT category
FROM products
ORDER BY category;

-- 3. Таблица categories
CREATE TABLE categories (
  id INTEGER
    GENERATED ALWAYS AS IDENTITY
    PRIMARY KEY,
  name VARCHAR(100)
    NOT NULL
    UNIQUE
);

-- 5. Перенос существующих категорий
INSERT INTO categories (name)
SELECT DISTINCT category
FROM products
ORDER BY category;

-- 6. Проверка категорий (1 Accessories, 2 Components, 3 Monitors)
SELECT *
FROM categories
ORDER BY id;

-- 8. Новый столбец пока без NOT NULL
ALTER TABLE products
  ADD COLUMN category_id INTEGER;

-- 9. Промежуточное состояние: category_id = NULL
SELECT
  id,
  name,
  category,
  category_id
FROM products
ORDER BY id;

-- 10. Заполнение category_id по текстовому названию
UPDATE products AS p
SET category_id = c.id
FROM categories AS c
WHERE p.category = c.name;

-- 11. Результат
SELECT
  id,
  name,
  category,
  category_id
FROM products
ORDER BY id;

-- 12. Должно быть 0 строк
SELECT *
FROM products
WHERE category_id IS NULL;

-- 13. category_id обязателен (если остались NULL — команда упадёт и транзакция откатится)
ALTER TABLE products
  ALTER COLUMN category_id
  SET NOT NULL;

-- 14. Внешний ключ
ALTER TABLE products
  ADD CONSTRAINT products_category_id_fkey
  FOREIGN KEY (category_id)
  REFERENCES categories(id);

-- 17. Проверка через JOIN: те же названия категорий
SELECT
  p.id,
  p.name,
  p.price,
  c.name AS category,
  p.in_stock
FROM products AS p
JOIN categories AS c
  ON c.id = p.category_id
ORDER BY p.id;

-- 18. Удаление старого текстового столбца
ALTER TABLE products
  DROP COLUMN category;

COMMIT;

-- 19. Окончательная структура: id, name, price, in_stock, category_id
SELECT *
FROM products
ORDER BY id;

-- 20. Итоговый JOIN
SELECT
  p.id,
  p.name,
  p.price,
  c.name AS category,
  p.in_stock AS "inStock"
FROM products AS p
JOIN categories AS c
  ON c.id = p.category_id
ORDER BY p.id;
