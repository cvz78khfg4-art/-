import { prisma } from "../config/prisma.js";

// ЛР-7: товары возвращаются вместе со связанной категорией.
// Для списка используется вложенный select — только нужные frontend поля.
// (Вариант с include: { category: true } вернул бы все поля Category.)
export async function getAllProducts() {
  return prisma.product.findMany({
    select: {
      id: true,
      name: true,
      price: true,
      inStock: true,
      category: {
        select: {
          id: true,
          name: true
        }
      }
    },
    orderBy: {
      id: "asc"
    }
  });
}

export async function findProductById(id) {
  return prisma.product.findUnique({
    where: {
      id
    },
    include: {
      category: true
    }
  });
}

export async function addProduct(data) {
  return prisma.product.create({
    data: {
      name: data.name,
      price: data.price,
      categoryId: data.categoryId,
      inStock: data.inStock
    }
  });
}

export async function updateProductById(id, changes) {
  const existing = await prisma.product.findUnique({
    where: {
      id
    }
  });

  if (!existing) {
    return null;
  }

  return prisma.product.update({
    where: {
      id
    },
    data: changes
  });
}

export async function deleteProductById(id) {
  const existing = await prisma.product.findUnique({
    where: {
      id
    }
  });

  if (!existing) {
    return null;
  }

  return prisma.product.delete({
    where: {
      id
    }
  });
}

export async function getAvailableProducts(minPrice = 10000) {
  return prisma.product.findMany({
    where: {
      price: {
        gte: minPrice
      },
      inStock: true
    },
    orderBy: {
      price: "asc"
    }
  });
}
