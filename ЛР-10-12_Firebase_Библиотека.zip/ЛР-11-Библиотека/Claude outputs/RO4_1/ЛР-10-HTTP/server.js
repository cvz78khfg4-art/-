// ЛР-10. Встроенный модуль HTTP
// Вариант 1: «Информационный узел системы»
const http = require('http');

const PORT = 3000;

const server = http.createServer((req, res) => {
  // Задание 4. Метод запроса и User-Agent клиента в консоль сервера
  console.log(`${req.method} ${req.url} | User-Agent: ${req.headers['user-agent'] || '—'}`);

  // Задание 3. /admin -> 403 Forbidden
  if (req.url === '/admin') {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Доступ ограничен');
    return;
  }

  // Задание 5. /html -> отдаём HTML-разметку
  if (req.url === '/html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end('<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><title>Инфо</title></head><body><h1>Инфо-панель</h1></body></html>');
    return;
  }

  // Задание 2. Русский текст с правильной кодировкой
  if (req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Система готова к работе');
    return;
  }

  // Задание 1. Любая другая страница -> 200 и приветствие
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Server Alpha is active');
});

server.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});
