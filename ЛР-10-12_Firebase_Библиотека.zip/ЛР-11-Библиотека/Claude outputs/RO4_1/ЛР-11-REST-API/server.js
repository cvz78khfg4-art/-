// ЛР-11. Работа с данными и API (REST)
// Вариант 1: «Учёт оборудования»
const http = require('http');

const PORT = 3000;

// Хранилище в памяти
let devices = [
  { id: 1, name: 'Монитор', status: 'work' },
  { id: 2, name: 'Ноутбук', status: 'repair' },
  { id: 3, name: 'Проектор', status: 'work' }
];

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

// Чтение тела запроса (JSON) — потоком, по частям
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1e6) reject(new Error('Слишком большое тело запроса'));
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (url.pathname !== '/devices') {
      return sendJson(res, 404, { error: 'Маршрут не найден' });
    }

    // Задания 1–2. GET /devices и фильтр ?status=
    if (req.method === 'GET') {
      const status = url.searchParams.get('status');
      const result = status ? devices.filter((d) => d.status === status) : devices;
      return sendJson(res, 200, result);
    }

    // Задания 3–5. POST /devices
    if (req.method === 'POST') {
      const raw = await readBody(req);
      let data;
      try {
        data = JSON.parse(raw || '{}');
      } catch {
        return sendJson(res, 400, { error: 'Некорректный JSON в теле запроса' });
      }

      // Задание 4. Валидация: поле name обязательно
      if (!data.name || typeof data.name !== 'string' || !data.name.trim()) {
        return sendJson(res, 400, { error: 'Поле "name" обязательно' });
      }

      const device = {
        id: devices.length ? Math.max(...devices.map((d) => d.id)) + 1 : 1,
        name: data.name.trim(),
        status: data.status || 'work'
      };
      devices.push(device);

      // Задание 5. Логирование
      console.log(`[ADD]: Добавлено устройство ${device.name}`);
      return sendJson(res, 201, device);
    }

    sendJson(res, 405, { error: `Метод ${req.method} не поддерживается` });
  } catch (err) {
    console.error('Ошибка сервера:', err.message);
    sendJson(res, 500, { error: 'Внутренняя ошибка сервера' });
  }
});

server.listen(PORT, () => console.log(`API запущено: http://localhost:${PORT}/devices`));
