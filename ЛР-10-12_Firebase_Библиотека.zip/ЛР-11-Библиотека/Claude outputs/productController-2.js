import {
  getAllProducts,
  findProductById
} from "../services/productService.js";
import { AppError } from "../errors/AppError.js";

export async function getProducts(
  req,
  res,
  next
) {
  try {
    const products =
      await getAllProducts();

    res.json(products);
  } catch (error) {
    next(error);
  }
}

export async function getProductById(
  req,
  res,
  next
) {
  try {
    const id =
      Number(req.params.id);

    const product =
      await findProductById(id);

    if (!product) {
      return next(
        new AppError(
          "Product not found",
          404
        )
      );
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}

// INSERT, UPDATE и DELETE через PostgreSQL реализуются в ЛР-2.
// До этого маршруты отвечают 501 Not Implemented, чтобы не работать
// со старым массивом и не терять данные.
function notImplemented(next) {
  next(
    new AppError(
      "Operation is not implemented yet: write operations with PostgreSQL are added in the next lab",
      501
    )
  );
}

export function createProduct(req, res, next) {
  notImplemented(next);
}

export function updateProduct(req, res, next) {
  notImplemented(next);
}

export function deleteProduct(req, res, next) {
  notImplemented(next);
}
