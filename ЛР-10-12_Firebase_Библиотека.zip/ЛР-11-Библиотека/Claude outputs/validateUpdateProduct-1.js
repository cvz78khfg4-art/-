import {
  isPositiveInteger
} from "../validators/productValidator.js";

export function validateUpdateProduct(
  req,
  res,
  next
) {
  const {
    name,
    price,
    categoryId,
    inStock
  } = req.body ?? {};

  const errors = [];

  if (
    name !== undefined &&
    (
      typeof name !== "string" ||
      !name.trim()
    )
  ) {
    errors.push(
      "name must be non-empty string"
    );
  }

  if (
    price !== undefined &&
    (
      typeof price !== "number" ||
      price <= 0
    )
  ) {
    errors.push(
      "price must be greater than 0"
    );
  }

  if (
    categoryId !== undefined &&
    !isPositiveInteger(categoryId)
  ) {
    errors.push(
      "categoryId must be a positive integer"
    );
  }

  if (
    inStock !== undefined &&
    typeof inStock !== "boolean"
  ) {
    errors.push(
      "inStock must be boolean"
    );
  }

  if (errors.length > 0) {
    return res.status(400).json({
      message: "Validation failed",
      errors
    });
  }

  next();
}
