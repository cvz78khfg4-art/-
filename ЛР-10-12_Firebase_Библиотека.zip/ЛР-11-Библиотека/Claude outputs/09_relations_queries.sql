-- ЛР-4. Запросы по связям 1:1, 1:N, M:N и расчёты.
--   psql -h localhost -U shop_user -d shop_db -f sql/09_relations_queries.sql

-- 7. Пользователь + профиль (LEFT JOIN покажет и пользователей без профиля)
SELECT
  u.id,
  u.name,
  u.email,
  p.phone,
  p.address
FROM users AS u
LEFT JOIN user_profiles AS p
  ON p.user_id = u.id
ORDER BY u.id;

-- 11. Несколько строк с user_id = 1 — это нормально
SELECT *
FROM orders
ORDER BY id;

-- 12. Заказы одного пользователя
SELECT
  id,
  user_id,
  status,
  created_at
FROM orders
WHERE user_id = 1
ORDER BY created_at DESC;

-- 13. Заказы вместе с пользователями (User 1 → N Orders)
SELECT
  o.id AS order_id,
  o.status,
  o.created_at,
  u.id AS user_id,
  u.name AS user_name,
  u.email
FROM orders AS o
JOIN users AS u
  ON u.id = o.user_id
ORDER BY o.id;

-- 18–19. Фактические id товаров и заказов
SELECT
  id,
  name,
  price
FROM products
ORDER BY id;

SELECT
  id,
  user_id,
  status
FROM orders
ORDER BY id;

-- 23. Товары заказа 1
SELECT
  p.id,
  p.name,
  oi.quantity,
  oi.price
FROM order_items AS oi
JOIN products AS p
  ON p.id = oi.product_id
WHERE oi.order_id = 1
ORDER BY p.name;

-- 24. Заказ с пользователем и товарами (users + orders + order_items + products)
SELECT
  o.id AS order_id,
  o.status,
  u.name AS user_name,
  p.name AS product_name,
  oi.quantity,
  oi.price
FROM orders AS o
JOIN users AS u
  ON u.id = o.user_id
JOIN order_items AS oi
  ON oi.order_id = o.id
JOIN products AS p
  ON p.id = oi.product_id
WHERE o.id = 1
ORDER BY p.name;

-- 25. Заказы, содержащие товар 1 (M:N в обратном направлении)
SELECT
  o.id AS order_id,
  o.status,
  o.created_at,
  oi.quantity
FROM order_items AS oi
JOIN orders AS o
  ON o.id = oi.order_id
WHERE oi.product_id = 1
ORDER BY o.created_at DESC;

-- 27. Количество меняется через UPDATE, а не повторной вставкой
UPDATE order_items
SET quantity = 3
WHERE order_id = 1
  AND product_id = 1;

SELECT *
FROM order_items
WHERE order_id = 1;

-- 29. Стоимость позиций
SELECT
  p.name,
  oi.quantity,
  oi.price,
  oi.quantity * oi.price AS line_total
FROM order_items AS oi
JOIN products AS p
  ON p.id = oi.product_id
WHERE oi.order_id = 1;

-- 30. Стоимость заказа
SELECT
  order_id,
  SUM(quantity * price) AS total
FROM order_items
WHERE order_id = 1
GROUP BY order_id;
