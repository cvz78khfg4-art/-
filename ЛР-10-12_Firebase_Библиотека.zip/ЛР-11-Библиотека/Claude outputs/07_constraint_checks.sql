-- ЛР-3, шаги 7 и 15. Проверка ограничений.
-- ОБА INSERT ДОЛЖНЫ ЗАВЕРШИТЬСЯ ОШИБКОЙ — это ожидаемый результат.
--   psql -h localhost -U shop_user -d shop_db -f sql/07_constraint_checks.sql

-- 7. UNIQUE: повторная категория отклоняется
--    ERROR: duplicate key value violates unique constraint "categories_name_key"
INSERT INTO categories (name)
VALUES ('Accessories');

-- 15. FOREIGN KEY: максимальный существующий id категории
SELECT MAX(id)
FROM categories;

-- Товар с несуществующим category_id отклоняется
--    ERROR: insert or update on table "products" violates foreign key constraint
--           "products_category_id_fkey"
-- (Запрос из методички содержит столбец category — он выполняется ДО шага 18,
--  пока столбец ещё существует. После удаления category используйте вариант ниже.)
INSERT INTO products
(
  name,
  price,
  category_id,
  in_stock
)
VALUES
(
  'Test Product',
  1000,
  999999,
  true
);

-- Проверка: ни одна ошибочная строка не добавлена
SELECT * FROM categories ORDER BY id;
SELECT * FROM products ORDER BY id;
