import { prisma } from "../config/prisma.js";

// ЛР-6: полный CRUD Product через Prisma Client.
// Здесь нет массива products[] и вызовов pool.query().

export async function getAllProducts() {
  return prisma.product.findMany({
    orderBy: {
      id: "asc"
    }
  });
}

export async function findProductById(id) {
  return prisma.product.findUnique({
    where: {
      id
    }
  });
}

export async function addProduct(data) {
  return prisma.product.create({
    data: {
      name: data.name,
      price: data.price,
      categoryId: data.categoryId,
      inStock: data.inStock
    }
  });
}

export async function updateProductById(id, changes) {
  const existing = await prisma.product.findUnique({
    where: {
      id
    }
  });

  if (!existing) {
    return null;
  }

  return prisma.product.update({
    where: {
      id
    },
    data: changes
  });
}

export async function deleteProductById(id) {
  const existing = await prisma.product.findUnique({
    where: {
      id
    }
  });

  if (!existing) {
    return null;
  }

  return prisma.product.delete({
    where: {
      id
    }
  });
}

// Шаг 12. Пример фильтрации и сортировки через findMany():
// товары от 10000 и в наличии, по возрастанию цены.
// Доступно через GET /api/products?available=true
export async function getAvailableProducts(minPrice = 10000) {
  return prisma.product.findMany({
    where: {
      price: {
        gte: minPrice
      },
      inStock: true
    },
    orderBy: {
      price: "asc"
    }
  });
}
