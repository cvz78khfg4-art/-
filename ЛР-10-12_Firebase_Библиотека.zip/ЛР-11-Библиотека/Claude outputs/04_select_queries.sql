-- ЛР-2, шаги 2–5. Базовые SELECT-запросы.
--   psql -h localhost -U shop_user -d shop_db -f sql/04_select_queries.sql

-- 2. Содержимое таблицы
SELECT
  id,
  name,
  price,
  category,
  in_stock
FROM products
ORDER BY id;

-- 3. Товары дороже 10000
SELECT
  id,
  name,
  price
FROM products
WHERE price > 10000;

-- 4. Дороже 10000 и в наличии
SELECT
  id,
  name,
  price
FROM products
WHERE price > 10000
  AND in_stock = true;

-- 5. В наличии, по возрастанию цены
SELECT
  id,
  name,
  price
FROM products
WHERE in_stock = true
ORDER BY price ASC;
