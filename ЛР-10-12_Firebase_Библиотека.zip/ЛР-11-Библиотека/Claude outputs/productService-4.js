import {
  pool
} from "../config/db.js";

// ЛР-1: источником данных стал PostgreSQL. Массив products[] удалён.
// Реализовано только чтение (SELECT); INSERT/UPDATE/DELETE — в ЛР-2.

export async function getAllProducts() {
  const result =
    await pool.query(
      `SELECT
         id,
         name,
         price,
         category,
         in_stock AS "inStock"
       FROM products
       ORDER BY id`
    );

  return result.rows;
}

export async function findProductById(
  id
) {
  const result =
    await pool.query(
      `SELECT
         id,
         name,
         price,
         category,
         in_stock AS "inStock"
       FROM products
       WHERE id = $1`,
      [id]
    );

  return result.rows[0];
}
