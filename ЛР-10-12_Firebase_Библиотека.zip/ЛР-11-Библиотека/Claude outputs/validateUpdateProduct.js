import {
  isPositiveInteger
} from "../validators/productValidator.js";

// Поля Product, которые разрешено менять через PATCH.
const ALLOWED_FIELDS = [
  "name",
  "price",
  "categoryId",
  "inStock"
];

export function validateUpdateProduct(
  req,
  res,
  next
) {
  const body = req.body ?? {};

  const {
    name,
    price,
    categoryId,
    inStock
  } = body;

  const errors = [];

  const unknownFields =
    Object.keys(body).filter(
      (key) => !ALLOWED_FIELDS.includes(key)
    );

  if (unknownFields.length > 0) {
    errors.push(
      `unknown fields: ${unknownFields.join(", ")}`
    );
  }

  if (
    name !== undefined &&
    (
      typeof name !== "string" ||
      !name.trim()
    )
  ) {
    errors.push(
      "name must be non-empty string"
    );
  }

  if (
    price !== undefined &&
    (
      typeof price !== "number" ||
      price <= 0
    )
  ) {
    errors.push(
      "price must be greater than 0"
    );
  }

  if (
    categoryId !== undefined &&
    !isPositiveInteger(categoryId)
  ) {
    errors.push(
      "categoryId must be a positive integer"
    );
  }

  if (
    inStock !== undefined &&
    typeof inStock !== "boolean"
  ) {
    errors.push(
      "inStock must be boolean"
    );
  }

  const changes = {};

  for (const field of ALLOWED_FIELDS) {
    if (body[field] !== undefined) {
      changes[field] = body[field];
    }
  }

  if (
    errors.length === 0 &&
    Object.keys(changes).length === 0
  ) {
    errors.push(
      "at least one field must be provided"
    );
  }

  if (errors.length > 0) {
    return res.status(400).json({
      message: "Validation failed",
      errors
    });
  }

  // В Service передаётся только отфильтрованный объект changes.
  req.body = changes;

  next();
}
