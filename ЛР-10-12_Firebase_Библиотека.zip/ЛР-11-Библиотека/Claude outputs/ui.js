const productsContainer =
  document.querySelector("#products");
const messageElement =
  document.querySelector("#message");

export function showMessage(text) {
  messageElement.textContent = text;
}

export function showError(text) {
  messageElement.textContent =
    `Ошибка: ${text}`;
}

// category может прийти строкой (SQL + JOIN), объектом (Prisma include)
// или отсутствовать (только categoryId).
function getCategoryName(product) {
  if (product.category && typeof product.category === "object") {
    return product.category.name;
  }

  return product.category ?? `id ${product.categoryId}`;
}

function createProductElement(
  product
) {
  const card =
    document.createElement("article");

  const title =
    document.createElement("h3");
  title.textContent = product.name;

  const price =
    document.createElement("p");
  price.textContent =
    `Цена: ${product.price} ₸`;

  const category =
    document.createElement("p");
  category.textContent =
    `Категория: ${getCategoryName(product)}`;

  const stock =
    document.createElement("p");
  stock.textContent =
    product.inStock
      ? "В наличии"
      : "Нет в наличии";

  const editButton =
    document.createElement("button");
  editButton.textContent =
    "Изменить цену";
  editButton.dataset.action = "edit";
  editButton.dataset.id = product.id;

  const deleteButton =
    document.createElement("button");
  deleteButton.textContent = "Удалить";
  deleteButton.dataset.action = "delete";
  deleteButton.dataset.id = product.id;

  card.append(
    title,
    price,
    category,
    stock,
    editButton,
    deleteButton
  );

  return card;
}

export function renderProducts(
  products
) {
  productsContainer.innerHTML = "";

  if (products.length === 0) {
    productsContainer.textContent =
      "Товаров нет";
    return;
  }

  for (const product of products) {
    productsContainer.append(
      createProductElement(product)
    );
  }
}
