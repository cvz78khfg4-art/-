-- ЛР-1, шаги 5–7. Выполнять в базе shop_db от имени shop_user:
--   psql -h localhost -U shop_user -d shop_db -f sql/02_create_products.sql

-- 5. Таблица products
CREATE TABLE products (
  id INTEGER
    GENERATED ALWAYS AS IDENTITY
    PRIMARY KEY,
  name VARCHAR(150)
    NOT NULL,
  price INTEGER
    NOT NULL
    CHECK (price > 0),
  category VARCHAR(100)
    NOT NULL,
  in_stock BOOLEAN
    NOT NULL
    DEFAULT true
);

-- 6. Тестовые данные
INSERT INTO products
(
  name,
  price,
  category,
  in_stock
)
VALUES
(
  'Keyboard',
  15000,
  'Accessories',
  true
),
(
  'Mouse',
  8000,
  'Accessories',
  true
),
(
  'Monitor',
  85000,
  'Monitors',
  false
);

-- 7. Проверка: должны появиться три товара
SELECT *
FROM products
ORDER BY id;
