import "dotenv/config";
import {
  PrismaPg
} from "@prisma/adapter-pg";
import {
  PrismaClient
} from "../generated/prisma/client.js";

const adapter =
  new PrismaPg({
    connectionString:
      process.env.DATABASE_URL
  });

// Один экземпляр PrismaClient на всё приложение.
export const prisma =
  new PrismaClient({
    adapter
  });
