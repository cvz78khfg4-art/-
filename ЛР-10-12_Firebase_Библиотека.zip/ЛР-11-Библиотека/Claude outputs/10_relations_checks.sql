-- ЛР-4, шаги 6, 14, 26, 28. Проверка ограничений.
-- ВСЕ ЧЕТЫРЕ КОМАНДЫ ДОЛЖНЫ ЗАВЕРШИТЬСЯ ОШИБКОЙ — это ожидаемый результат.
--   psql -h localhost -U shop_user -d shop_db -f sql/10_relations_checks.sql

-- 6. Второй профиль того же пользователя (1:1)
--    ERROR: duplicate key value violates unique constraint "user_profiles_pkey"
INSERT INTO user_profiles
(
  user_id,
  phone,
  address
)
VALUES
(
  1,
  '+7 777 999 88 77',
  'Astana'
);

-- 14. Заказ несуществующего пользователя
--    ERROR: ... violates foreign key constraint "orders_user_id_fkey"
INSERT INTO orders
  (user_id, status)
VALUES
  (999999, 'new');

-- 26. Повтор пары (order_id, product_id)
--    ERROR: duplicate key value violates unique constraint "order_items_pkey"
INSERT INTO order_items
(
  order_id,
  product_id,
  quantity,
  price
)
VALUES
(
  1,
  1,
  5,
  15000
);

-- 28. quantity = 0
--    ERROR: new row for relation "order_items" violates check constraint
--           "order_items_quantity_check"
UPDATE order_items
SET quantity = 0
WHERE order_id = 1
  AND product_id = 1;

-- Данные не изменились
SELECT * FROM user_profiles ORDER BY user_id;
SELECT * FROM orders ORDER BY id;
SELECT * FROM order_items ORDER BY order_id, product_id;
