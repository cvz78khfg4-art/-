// Ошибки ограничений PostgreSQL (коды SQLSTATE) превращаются в понятные
// клиентские ответы; всё остальное по-прежнему 500 без технических деталей.
const pgErrors = {
  "23503": { statusCode: 400, message: "Related record not found (foreign key violation)" },
  "23505": { statusCode: 409, message: "Duplicate value (unique violation)" },
  "23514": { statusCode: 400, message: "Check constraint violation" },
  "22P02": { statusCode: 400, message: "Invalid input value" }
};

export function errorHandler(
  err,
  req,
  res,
  next
) {
  const pgError = pgErrors[err.code];

  const statusCode =
    err.statusCode || pgError?.statusCode || 500;

  console.error(err);

  res
    .status(statusCode)
    .json({
      message:
        statusCode === 500
          ? "Internal server error"
          : pgError?.message ?? err.message
    });
}
