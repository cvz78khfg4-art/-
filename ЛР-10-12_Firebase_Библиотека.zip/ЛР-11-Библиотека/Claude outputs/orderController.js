import {
  getOrderDetails,
  getOrderItems
} from "../services/orderService.js";
import { AppError } from "../errors/AppError.js";

export async function getOrderById(req, res, next) {
  try {
    const id = Number(req.params.id);
    const order = await getOrderDetails(id);

    if (!order) {
      return next(new AppError("Order not found", 404));
    }

    res.json(order);
  } catch (error) {
    next(error);
  }
}

export async function getOrderItemsById(req, res, next) {
  try {
    const id = Number(req.params.id);
    const items = await getOrderItems(id);

    if (!items) {
      return next(new AppError("Order not found", 404));
    }

    res.json(items);
  } catch (error) {
    next(error);
  }
}
