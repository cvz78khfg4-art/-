-- ЛР-2, шаги 6–10. INSERT / RETURNING / UPDATE / DELETE вручную.
--   psql -h localhost -U shop_user -d shop_db -f sql/05_manual_crud.sql
--
-- Ожидаемое состояние перед запуском (после ЛР-1):
--   1 Keyboard, 2 Mouse, 3 Monitor, 4 SSD 2TB.
-- Шаг 6 (INSERT 'SSD 2TB') уже выполнен в ЛР-1 скриптом 03_insert_ssd.sql,
-- поэтому здесь он закомментирован, чтобы не создать дубликат:
--
-- INSERT INTO products (name, price, category, in_stock)
-- VALUES ('SSD 2TB', 65000, 'Components', true);

SELECT *
FROM products
ORDER BY id;

-- 7. INSERT ... RETURNING (Web Camera получит id = 5)
INSERT INTO products
(
  name,
  price,
  category,
  in_stock
)
VALUES
(
  'Web Camera',
  22000,
  'Accessories',
  true
)
RETURNING
  id,
  name,
  price,
  category,
  in_stock;

-- 8. UPDATE c WHERE (используйте фактический id Web Camera)
UPDATE products
SET price = 20000
WHERE id = 5
RETURNING *;

-- 9. ОПАСНО — не выполнять: изменит цену всех строк!
-- UPDATE products
-- SET price = 20000;

-- 10. DELETE c WHERE: удаляется только нужная строка
DELETE FROM products
WHERE id = 5
RETURNING *;

SELECT *
FROM products
ORDER BY id;
