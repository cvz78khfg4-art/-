// Централизованный обработчик ошибок.
// Известные ошибки Prisma (коды Pxxxx) и PostgreSQL (SQLSTATE) превращаются
// в понятные клиентские ответы; остальные — 500 без технических деталей.
const knownErrors = {
  // Prisma Client
  P2025: { statusCode: 404, message: "Record not found" },
  P2002: { statusCode: 409, message: "Duplicate value (unique constraint failed)" },
  P2003: { statusCode: 400, message: "Related record constraint failed (foreign key)" },
  // PostgreSQL через pg Pool
  "23503": { statusCode: 400, message: "Related record constraint failed (foreign key)" },
  "23505": { statusCode: 409, message: "Duplicate value (unique constraint failed)" },
  "23514": { statusCode: 400, message: "Check constraint violation" },
  "22P02": { statusCode: 400, message: "Invalid input value" }
};

export function errorHandler(
  err,
  req,
  res,
  next
) {
  let known = knownErrors[err.code];

  if (!known && err.name === "PrismaClientValidationError") {
    known = { statusCode: 400, message: "Invalid request data" };
  }

  const statusCode =
    err.statusCode || known?.statusCode || 500;

  console.error(err);

  res
    .status(statusCode)
    .json({
      message:
        statusCode === 500
          ? "Internal server error"
          : known?.message ?? err.message
    });
}
