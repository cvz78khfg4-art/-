import {
  pool
} from "../config/db.js";

// ЛР-3: категория вынесена в таблицу categories.
// Название категории получаем через JOIN, наружу API отдаёт
// categoryId и category (название) — как удобно frontend.

export async function getAllProducts() {
  const result =
    await pool.query(
      `SELECT
         p.id,
         p.name,
         p.price,
         p.category_id AS "categoryId",
         c.name AS category,
         p.in_stock AS "inStock"
       FROM products AS p
       JOIN categories AS c
         ON c.id = p.category_id
       ORDER BY p.id`
    );

  return result.rows;
}

export async function findProductById(
  id
) {
  const result =
    await pool.query(
      `SELECT
         p.id,
         p.name,
         p.price,
         p.category_id AS "categoryId",
         c.name AS category,
         p.in_stock AS "inStock"
       FROM products AS p
       JOIN categories AS c
         ON c.id = p.category_id
       WHERE p.id = $1`,
      [id]
    );

  return result.rows[0];
}

// Столбца products.category больше нет, поэтому CREATE/UPDATE работают
// с category_id. Ответ дополняется названием категории через CTE + JOIN.

export async function addProduct(
  data
) {
  const result =
    await pool.query(
      `WITH inserted AS (
         INSERT INTO products
         (
           name,
           price,
           category_id,
           in_stock
         )
         VALUES
           ($1, $2, $3, $4)
         RETURNING *
       )
       SELECT
         i.id,
         i.name,
         i.price,
         i.category_id AS "categoryId",
         c.name AS category,
         i.in_stock AS "inStock"
       FROM inserted AS i
       JOIN categories AS c
         ON c.id = i.category_id`,
      [
        data.name,
        data.price,
        data.categoryId,
        data.inStock
      ]
    );

  return result.rows[0];
}

export async function updateProductById(
  id,
  changes
) {
  const result =
    await pool.query(
      `WITH updated AS (
         UPDATE products
         SET
           name =
             COALESCE($1, name),
           price =
             COALESCE($2, price),
           category_id =
             COALESCE($3, category_id),
           in_stock =
             COALESCE($4, in_stock)
         WHERE id = $5
         RETURNING *
       )
       SELECT
         u.id,
         u.name,
         u.price,
         u.category_id AS "categoryId",
         c.name AS category,
         u.in_stock AS "inStock"
       FROM updated AS u
       JOIN categories AS c
         ON c.id = u.category_id`,
      [
        changes.name ?? null,
        changes.price ?? null,
        changes.categoryId ?? null,
        changes.inStock ?? null,
        id
      ]
    );

  return result.rows[0];
}

export async function deleteProductById(
  id
) {
  const result =
    await pool.query(
      `WITH deleted AS (
         DELETE FROM products
         WHERE id = $1
         RETURNING *
       )
       SELECT
         d.id,
         d.name,
         d.price,
         d.category_id AS "categoryId",
         c.name AS category,
         d.in_stock AS "inStock"
       FROM deleted AS d
       JOIN categories AS c
         ON c.id = d.category_id`,
      [id]
    );

  return result.rows[0];
}
