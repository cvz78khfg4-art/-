import {
  prisma
} from "../config/prisma.js";

// ЛР-5: чтение товаров переведено на Prisma Client.
// Было (pg):  pool.query("SELECT ... FROM products WHERE id = $1", [id])
// Стало:      prisma.product.findUnique({ where: { id } })

export async function getAllProducts() {
  return prisma.product.findMany({
    include: {
      category: true
    },
    orderBy: {
      id: "asc"
    }
  });
}

export async function findProductById(
  id
) {
  return prisma.product.findUnique({
    where: {
      id
    },
    include: {
      category: true
    }
  });
}

// Полный CRUD через Prisma — тема ЛР-6. До этого операции записи
// выполняет прежняя SQL-версия сервиса, поэтому REST API не меняется.
export {
  addProduct,
  updateProductById,
  deleteProductById
} from "./productService.sql.js";
