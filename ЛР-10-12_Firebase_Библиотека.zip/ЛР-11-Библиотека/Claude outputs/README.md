# ПМ4 Node.js — РО4.2, лабораторные работы 1–9 (Вариант 1)

Студент: **Стариков Юрий**, группа **15 ТИС**

Проект **Internet Shop API** (`express-shop`) на Express.js, ES-модули (`"type": "module"`).
Проект накопительный: каждая папка — полный рабочий снимок проекта после соответствующей ЛР.
Нужен Node.js 18+ (`node -v`). Все команды выполняются **из папки ЛР**:

```bash
npm install      # установит express (node_modules и package-lock.json создаются здесь)
npm start        # Server: http://localhost:3000
npm run dev      # то же, с автоперезапуском (node --watch)
```

В каждой папке есть `requests.http` — готовые запросы для VS Code (REST Client / Thunder Client).
Данные хранятся в памяти: после перезапуска сервера возвращаются к исходным.

| ЛР | Тема | Папка |
|---|---|---|
| 1 | Первое серверное приложение на Express.js | `ЛР-01-Express` |
| 2 | Маршрутизация и HTTP-методы | `ЛР-02-HTTP-методы` |
| 3 | Параметры маршрутов, query-параметры, тело запроса | `ЛР-03-params-query-body` |
| 4 | Разделение маршрутов с помощью Router | `ЛР-04-Router` |
| 5 | Собственные middleware | `ЛР-05-Middleware` |
| 6 | Разделение на routes, controllers, services | `ЛР-06-Controllers-Services` |
| 7 | REST API и CRUD-операции | `ЛР-07-REST-CRUD` |
| 8 | Валидация входных данных и обработка ошибок | `ЛР-08-Валидация-ошибки` |
| 9 | Интеграция REST API с клиентским приложением | `ЛР-09-Frontend` |

---

## ЛР-1. Первое приложение на Express.js
`app.js` — шесть GET-маршрутов: текст через `res.send()`, объекты и массивы через `res.json()`;
5 товаров, 3 категории.
```bash
curl http://localhost:3000/                 # Internet Shop API
curl http://localhost:3000/about            # Учебный REST API интернет-магазина компьютерной техники
curl http://localhost:3000/api/status       # {"status":"ok","message":"Server is running"}
curl http://localhost:3000/api/shop         # {"name":"Tech Store",…,"currency":"KZT"}
curl http://localhost:3000/api/products     # массив из 5 товаров
curl http://localhost:3000/api/categories   # ["Computers","Accessories","Monitors"]
```

## ЛР-2. Маршрутизация и HTTP-методы
Один URL `/api/products` — пять методов; ресурсы products, categories, orders; именованный обработчик `getProducts`.
```bash
curl http://localhost:3000/api                              # {"name":"Internet Shop API","version":"1.0","resources":[…]}
curl -i -X POST   http://localhost:3000/api/products        # 201 {"message":"POST route: product creation"}
curl -i -X PUT    http://localhost:3000/api/products        # 200 {"message":"PUT route: full product replacement"}
curl    -X PATCH  http://localhost:3000/api/products        # {"message":"PATCH route: partial product update"}
curl    -X DELETE http://localhost:3000/api/products        # {"message":"DELETE route: product deletion"}
curl -i -X POST   http://localhost:3000/api/categories      # 201 {"message":"POST route: category creation"}
curl http://localhost:3000/api/orders                       # []
curl -i -X POST   http://localhost:3000/api/orders          # 201 {"message":"POST route: order creation"}
curl -i -X DELETE http://localhost:3000/api/orders          # 404 Cannot DELETE /api/orders
```
Вывод: маршрут с одним методом не означает наличие маршрута с другим методом для того же URL.

## ЛР-3. req.params, req.query, req.body
```bash
curl http://localhost:3000/api/products/3                   # {"id":3,"name":"Monitor",…}
curl -i http://localhost:3000/api/products/999              # 404 {"message":"Product not found"}
curl "http://localhost:3000/api/products?category=Accessories&inStock=true"   # Keyboard, Mouse
curl "http://localhost:3000/api/products?minPrice=10000&maxPrice=50000"       # Keyboard, Webcam
curl -i -X POST http://localhost:3000/api/products -H "Content-Type: application/json" \
  -d '{"name":"Headphones","price":35000,"category":"Accessories","inStock":true}'   # 201 {"id":6,…}
curl -X PATCH http://localhost:3000/api/products/3 -H "Content-Type: application/json" \
  -d '{"price":79000,"inStock":true}'                       # Monitor: price 79000, inStock true
curl -X DELETE http://localhost:3000/api/products/2         # удалённый товар Mouse
curl -X PATCH "http://localhost:3000/api/products/4/settings?notify=true" -H "Content-Type: application/json" \
  -d '{"price":399000}'                                     # {"id":4,"notify":true,"changes":{"price":399000}}
```
Тело POST выводится в терминал (`console.log(req.body)`).

## ЛР-4. Router
`routes/productRoutes.js`, `categoryRoutes.js`, `orderRoutes.js` (`express.Router()`, `export default router`),
подключаются в `app.js` через `app.use("/api/…", router)`. URL не изменились.
```bash
curl http://localhost:3000/api/products/1                   # router.get("/:id") → GET /api/products/1
curl -X PATCH http://localhost:3000/api/products/1 -H "Content-Type: application/json" -d '{"price":14000}'
curl -X DELETE http://localhost:3000/api/products/1         # удалённый товар; повторный GET → 404
curl http://localhost:3000/api/orders/1                     # {"id":1,"productId":4,"quantity":1,"status":"new"}
curl -i -X POST http://localhost:3000/api/orders -H "Content-Type: application/json" \
  -d '{"productId":2,"quantity":3}'                         # 201 {"id":3,"status":"new",…}
curl -X PATCH http://localhost:3000/api/orders/1 -H "Content-Type: application/json" -d '{"status":"shipped"}'
```

## ЛР-5. Middleware
`middleware/logger.js` (глобальный), `requestTime.js` (`req.requestTime`), `checkApiKey.js` (route-level на
`POST /api/products`), Router-level middleware в `productRoutes.js`.
```bash
curl http://localhost:3000/api/status    # {"status":"ok","requestTime":"2026-…Z"}
B='{"name":"SSD 1TB","price":45000,"category":"Components","inStock":true}'
curl -i -X POST http://localhost:3000/api/products -H "Content-Type: application/json" -d "$B"
                                         # 403 {"message":"Access denied"}
curl -i -X POST http://localhost:3000/api/products -H "Content-Type: application/json" -H "x-api-key: wrong-key" -d "$B"
                                         # 403 {"message":"Access denied"}
curl -i -X POST http://localhost:3000/api/products -H "Content-Type: application/json" -H "x-api-key: college-demo" -d "$B"
                                         # 201 {"id":6,"name":"SSD 1TB",…}
```
В терминале: `2026-… GET /api/products/1` и `Product Router: GET /api/products/1`; для `/api/categories`
и `/api/orders` строки `Product Router:` нет.
Эксперименты: без `next()` в Router-level middleware запрос «зависает» (ответ не отправлен, цепочка не
продолжена); если `express.json()` подключить после routers, `req.body` в обработчике будет `undefined`.

## ЛР-6. routes → controllers → services
`services/productService.js` — данные и операции (без `req`/`res`), `controllers/productController.js` — работа
с HTTP, `routes/productRoutes.js` — только описание endpoints. `app.js` импортирует только routers.
```bash
curl -i http://localhost:3000/api/products/999              # 404 {"message":"Product not found"}
curl -i -X POST http://localhost:3000/api/products -H "Content-Type: application/json" -H "x-api-key: college-demo" \
  -d '{"name":"SSD 1TB","price":45000,"category":"Components","inStock":true}'   # 201
curl -X PATCH http://localhost:3000/api/products/1 -H "Content-Type: application/json" \
  -d '{"price":13500,"inStock":false}'                      # изменились только price и inStock
curl -X DELETE http://localhost:3000/api/products/2 && curl -i http://localhost:3000/api/products/2   # затем 404
grep -nwE "req|res" services/productService.js             # пусто — архитектурное правило соблюдено
```

## ЛР-7. REST API и CRUD
Исходно 3 товара; `POST` открыт (без API-ключа), как в коде задания. Полный CRUD-цикл:
```bash
curl -i -X POST http://localhost:3000/api/products -H "Content-Type: application/json" \
  -d '{"name":"SSD 1TB","price":45000,"category":"Components","inStock":true}'   # 201 {"id":4,…}
curl http://localhost:3000/api/products/4                   # товар существует
curl -X PATCH http://localhost:3000/api/products/4 -H "Content-Type: application/json" \
  -d '{"price":42000,"inStock":false}'                      # name и category не изменились
curl -X DELETE http://localhost:3000/api/products/4         # удалённый товар
curl -i http://localhost:3000/api/products/4                # 404 {"message":"Product not found"}
```
Дополнительное задание — CRUD категорий (`categoryRoutes` → `categoryController` → `categoryService`):
```bash
curl http://localhost:3000/api/categories/2                 # {"id":2,"name":"Accessories"}
curl -i -X POST http://localhost:3000/api/categories -H "Content-Type: application/json" -d '{"name":"Components"}'  # 201 {"id":4,…}
curl -X PATCH http://localhost:3000/api/categories/4 -H "Content-Type: application/json" -d '{"name":"PC Components"}'
curl -X DELETE http://localhost:3000/api/categories/4       # затем GET /api/categories/4 → 404
```

## ЛР-8. Валидация и обработка ошибок
`validators/productValidator.js`, `middleware/validateCreateProduct.js`, `validateUpdateProduct.js`,
`errors/AppError.js`, `middleware/notFound.js`, `middleware/errorHandler.js` (подключены в конце `app.js`).
```bash
J='Content-Type: application/json'
curl -i -X POST http://localhost:3000/api/products -H "$J" \
  -d '{"name":"SSD 2TB","price":65000,"category":"Components","inStock":true}'   # 201
curl -i -X POST http://localhost:3000/api/products -H "$J" \
  -d '{"price":65000,"category":"Components","inStock":true}'
  # 400 {"message":"Validation failed","errors":["name is required"]}
curl -X POST http://localhost:3000/api/products -H "$J" -d '{"name":"","price":-100,"category":123,"inStock":"yes"}'
  # 400, errors: name is required, price must be greater than 0, category is required, inStock must be boolean
curl -X PATCH http://localhost:3000/api/products/1 -H "$J" -d '{"price":48000}'    # 200
curl -i -X PATCH http://localhost:3000/api/products/1 -H "$J" -d '{"price":-9000}' # 400, цена не изменилась
curl -i http://localhost:3000/api/products/999   # 404 {"message":"Product not found"}
curl -i http://localhost:3000/api/unknown        # 404 {"message":"Route GET /api/unknown not found"}
```
Проверка 500: раскомментируйте тестовый маршрут в конце `routes/productRoutes.js`, затем
`curl -i http://localhost:3000/api/products/test/error` → `500 {"message":"Internal server error"}`
(подробности ошибки — только в терминале сервера). После проверки маршрут снова закомментировать.

## ЛР-9. Frontend
`app.use(express.static("public"))`; `public/index.html`, `css/style.css`, `js/api.js` (fetch, проверка
`response.ok`), `js/ui.js` (DOM), `js/app.js` (события). Откройте **http://localhost:3000**.

Проверка в браузере (F12 → Network):
1. Открытие страницы → `GET /api/products`, карточки Keyboard, Mouse, Monitor.
2. Форма «SSD 2TB / 65000 / Components / в наличии» → `POST /api/products` 201, форма очищается,
   «Товар успешно добавлен», карточка появляется.
3. Цена `-100` → 400, «Ошибка: Validation failed: price must be greater than 0», товар не добавлен.
4. «Изменить цену» → `42000` → `PATCH /api/products/3` `{"price":42000}`, «Цена изменена»; `-500` → ошибка, цена прежняя.
5. «Удалить» → подтверждение → `DELETE /api/products/:id`, «Товар удалён», карточка исчезает.
6. Консоль: `await shopApi.updateProduct(999, {price: 1})` → `Error: Product not found` (404 обработан, страница работает).

```bash
curl -i http://localhost:3000/              # 200 text/html — public/index.html
curl -i http://localhost:3000/js/app.js     # 200 клиентский скрипт
```

---

Все ЛР проверены запуском (Node.js 22): ответы и коды статусов совпадают с указанными выше; frontend ЛР-9
проверен в headless-браузере (создание, ошибка валидации, изменение цены, удаление, 404 из консоли).
