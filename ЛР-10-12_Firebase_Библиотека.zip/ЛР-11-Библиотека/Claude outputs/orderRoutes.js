import { Router } from "express";
import {
  getOrderById,
  getOrderItemsById
} from "../controllers/orderController.js";

const router = Router();

router.get("/:id", getOrderById);
router.get("/:id/items", getOrderItemsById);

export default router;
