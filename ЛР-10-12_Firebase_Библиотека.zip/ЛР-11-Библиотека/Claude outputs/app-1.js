import {
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct
} from "./api.js";
import {
  renderProducts,
  showMessage,
  showError
} from "./ui.js";

async function loadProducts() {
  try {
    const products =
      await getProducts();
    renderProducts(products);
  } catch (error) {
    showError(error.message);
  }
}

document.addEventListener(
  "DOMContentLoaded",
  loadProducts
);

const form =
  document.querySelector(
    "#product-form"
  );

form.addEventListener(
  "submit",
  async (event) => {
    event.preventDefault();

    const product = {
      name:
        document
          .querySelector("#name")
          .value
          .trim(),
      price:
        Number(
          document
            .querySelector("#price")
            .value
        ),
      category:
        document
          .querySelector("#category")
          .value
          .trim(),
      inStock:
        document
          .querySelector("#inStock")
          .checked
    };

    try {
      await createProduct(product);
      form.reset();
      showMessage(
        "Товар успешно добавлен"
      );
      await loadProducts();
    } catch (error) {
      showError(error.message);
    }
  }
);

const productsContainer =
  document.querySelector(
    "#products"
  );

productsContainer.addEventListener(
  "click",
  async (event) => {
    const button =
      event.target.closest(
        "button[data-action]"
      );

    if (!button) {
      return;
    }

    const id =
      Number(button.dataset.id);
    const action =
      button.dataset.action;

    if (action === "delete") {
      await handleDelete(id);
    }

    if (action === "edit") {
      await handleEdit(id);
    }
  }
);

async function handleDelete(id) {
  const confirmed =
    confirm(
      "Удалить этот товар?"
    );

  if (!confirmed) {
    return;
  }

  try {
    await deleteProduct(id);
    showMessage(
      "Товар удалён"
    );
    await loadProducts();
  } catch (error) {
    showError(error.message);
  }
}

async function handleEdit(id) {
  const value =
    prompt(
      "Введите новую цену"
    );

  if (value === null) {
    return;
  }

  const price = Number(value);

  if (!Number.isFinite(price)) {
    showError(
      "Цена должна быть числом"
    );
    return;
  }

  try {
    await updateProduct(
      id,
      { price }
    );
    showMessage(
      "Цена изменена"
    );
    await loadProducts();
  } catch (error) {
    showError(error.message);
  }
}
