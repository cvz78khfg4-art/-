// ЛР-3. Параметры маршрутов (req.params), query-параметры (req.query) и тело запроса (req.body)
import express from "express";

const app = express();
const PORT = 3000;

// Разбор JSON-тела запроса — подключается ДО маршрутов, использующих req.body
app.use(express.json());

const shop = {
  name: "Tech Store",
  description: "Учебный интернет-магазин компьютерной техники",
  currency: "KZT"
};

let products = [
  { id: 1, name: "Keyboard", price: 15000, category: "Accessories", inStock: true },
  { id: 2, name: "Mouse", price: 8000, category: "Accessories", inStock: true },
  { id: 3, name: "Monitor", price: 85000, category: "Monitors", inStock: false },
  { id: 4, name: "Laptop", price: 420000, category: "Computers", inStock: true },
  { id: 5, name: "Webcam", price: 22000, category: "Accessories", inStock: false }
];

const categories = ["Computers", "Accessories", "Monitors"];
const orders = [];

// Следующий свободный id (max + 1 — не повторяется после удаления товаров)
function nextProductId() {
  return products.reduce((max, p) => Math.max(max, p.id), 0) + 1;
}

// ---------- Общие маршруты ----------
app.get("/", (req, res) => {
  res.send("Internet Shop API");
});

app.get("/about", (req, res) => {
  res.send("Учебный REST API интернет-магазина компьютерной техники");
});

app.get("/api", (req, res) => {
  res.json({
    name: "Internet Shop API",
    version: "1.0",
    resources: ["/api/products", "/api/categories", "/api/orders"]
  });
});

app.get("/api/status", (req, res) => {
  res.json({ status: "ok", message: "Server is running" });
});

app.get("/api/shop", (req, res) => {
  res.json(shop);
});

// ---------- products ----------

// GET /api/products?category=&inStock=&minPrice=&maxPrice=
// Фильтры применяются последовательно к одному массиву result
function getProducts(req, res) {
  const { category, inStock, minPrice, maxPrice } = req.query;
  let result = products;

  if (category) {
    result = result.filter(product => product.category === category);
  }
  if (inStock !== undefined) {
    // значение query-параметра всегда строка
    const isInStock = inStock === "true";
    result = result.filter(product => product.inStock === isInStock);
  }
  if (minPrice !== undefined) {
    result = result.filter(product => product.price >= Number(minPrice));
  }
  if (maxPrice !== undefined) {
    result = result.filter(product => product.price <= Number(maxPrice));
  }

  res.json(result);
}

app.get("/api/products", getProducts);

// GET /api/products/:id — один товар
app.get("/api/products/:id", (req, res) => {
  const id = Number(req.params.id); // id приходит строкой — преобразуем в число
  const product = products.find(product => product.id === id);

  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }
  res.json(product);
});

// POST /api/products — создание товара из JSON-тела
app.post("/api/products", (req, res) => {
  console.log(req.body); // проверка содержимого req.body (шаг 8)

  const newProduct = {
    id: nextProductId(),
    ...req.body
  };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

// PATCH /api/products/:id — частичное изменение (только переданные свойства)
app.patch("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const product = products.find(product => product.id === id);

  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }
  Object.assign(product, req.body);
  res.json(product);
});

// DELETE /api/products/:id — удаление по идентификатору
app.delete("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = products.findIndex(product => product.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Product not found" });
  }
  const [deletedProduct] = products.splice(index, 1);
  res.json(deletedProduct);
});

// PATCH /api/products/:id/settings?notify=true — params + query + body вместе
app.patch("/api/products/:id/settings", (req, res) => {
  res.json({
    id: Number(req.params.id),          // из req.params
    notify: req.query.notify === "true", // из req.query
    changes: req.body                    // из req.body
  });
});

// ---------- categories ----------
app.get("/api/categories", (req, res) => {
  res.json(categories);
});

app.post("/api/categories", (req, res) => {
  res.status(201).json({ message: "POST route: category creation" });
});

// ---------- orders ----------
app.get("/api/orders", (req, res) => {
  res.json(orders);
});

app.post("/api/orders", (req, res) => {
  res.status(201).json({ message: "POST route: order creation" });
});

app.listen(PORT, () => {
  console.log(`Server: http://localhost:${PORT}`);
});
