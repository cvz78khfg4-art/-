-- ЛР-1, шаг 28. Проверка постоянного хранения: товар добавляется напрямую в БД
-- (pgAdmin / psql) при запущенном Express, затем GET /api/products его показывает.
--   psql -h localhost -U shop_user -d shop_db -f sql/03_insert_ssd.sql

INSERT INTO products
(
  name,
  price,
  category,
  in_stock
)
VALUES
(
  'SSD 2TB',
  65000,
  'Components',
  true
);

SELECT *
FROM products
ORDER BY id;
