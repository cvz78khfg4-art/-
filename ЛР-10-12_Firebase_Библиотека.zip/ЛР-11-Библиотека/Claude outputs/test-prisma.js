// Временный тест Prisma (шаги 19–25). Запуск: npx tsx test-prisma.js
// После проверки файл можно удалить.
import {
  prisma
} from "./config/prisma.js";

try {
  // 19–21. Все товары, по возрастанию id
  const products =
    await prisma.product.findMany({
      orderBy: {
        id: "asc"
      }
    });
  console.log("findMany:", products);

  // 22. Поиск по существующему id
  const product =
    await prisma.product.findUnique({
      where: {
        id: 1
      }
    });
  console.log("findUnique(1):", product);

  // 23. Отсутствующий id → null
  const missing =
    await prisma.product.findUnique({
      where: {
        id: 999999
      }
    });
  console.log("findUnique(999999):", missing);

  // 24. Фильтрация: дороже 10000 и в наличии
  const filtered =
    await prisma.product.findMany({
      where: {
        price: {
          gt: 10000
        },
        inStock: true
      }
    });
  console.log("price > 10000 AND inStock:", filtered);

  // 25. Товары вместе с категорией
  const withCategory =
    await prisma.product.findMany({
      include: {
        category: true
      },
      orderBy: {
        id: "asc"
      }
    });
  console.log("include category:", withCategory);
} catch (error) {
  console.error("Prisma error:", error.message);
} finally {
  await prisma.$disconnect();
}
