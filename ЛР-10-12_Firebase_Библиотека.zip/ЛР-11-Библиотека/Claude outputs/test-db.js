// Временный тест подключения (шаги 14–16). После проверки файл можно удалить.
import {
  pool
} from "./config/db.js";

try {
  const result =
    await pool.query(
      "SELECT NOW() AS current_time"
    );

  console.log(
    "PostgreSQL connected:"
  );
  console.log(
    result.rows[0]
  );
} catch (error) {
  console.error(
    "Database connection error:"
  );
  console.error(
    error.message
  );
} finally {
  await pool.end();
}
