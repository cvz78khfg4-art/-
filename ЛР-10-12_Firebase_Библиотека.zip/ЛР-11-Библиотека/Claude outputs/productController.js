import {
  getAllProducts,
  findProductById,
  addProduct,
  updateProductById,
  deleteProductById,
  getAvailableProducts
} from "../services/productService.js";
import { findOrdersByProduct } from "../services/orderService.js";
import { AppError } from "../errors/AppError.js";

export async function getProducts(req, res, next) {
  try {
    // GET /api/products?available=true — пример where + orderBy
    const products =
      req.query.available === "true"
        ? await getAvailableProducts()
        : await getAllProducts();

    res.json(products);
  } catch (error) {
    next(error);
  }
}

export async function getProductById(req, res, next) {
  try {
    const id = Number(req.params.id);
    const product = await findProductById(id);

    if (!product) {
      return next(new AppError("Product not found", 404));
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}

// GET /api/products/:id/orders — заказы, содержащие товар.
// Для отсутствующего товара — 404, а не пустой массив.
export async function getProductOrders(req, res, next) {
  try {
    const id = Number(req.params.id);
    const product = await findProductById(id);

    if (!product) {
      return next(new AppError("Product not found", 404));
    }

    const orders = await findOrdersByProduct(id);
    res.json(orders);
  } catch (error) {
    next(error);
  }
}

export async function createProduct(req, res, next) {
  try {
    const product = await addProduct(req.body);
    res.status(201).json(product);
  } catch (error) {
    next(error);
  }
}

export async function updateProduct(req, res, next) {
  try {
    const id = Number(req.params.id);
    const product = await updateProductById(id, req.body);

    if (!product) {
      return next(new AppError("Product not found", 404));
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}

export async function deleteProduct(req, res, next) {
  try {
    const id = Number(req.params.id);
    const product = await deleteProductById(id);

    if (!product) {
      return next(new AppError("Product not found", 404));
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
}
