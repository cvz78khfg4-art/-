-- ЛР-1, шаги 2–3. Выполнять с правами администратора (пользователь postgres):
--   psql -h localhost -U postgres -f sql/01_create_user_and_db.sql
-- Пароль college123 используется только для учебной локальной среды.

CREATE USER shop_user
  WITH PASSWORD 'college123';

CREATE DATABASE shop_db
  OWNER shop_user;
