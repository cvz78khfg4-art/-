# Схема базы данных TechShop (Cloud Firestore)

Firestore — документная NoSQL-база. Данные хранятся в **коллекциях** документов.
Схема спроектирована под запросы приложения: часть данных **дублируется**
(денормализация), чтобы страницы читали минимум документов.

## Обзор коллекций

| Коллекция | Назначение (по ТЗ, п. 4.1) | ID документа | Кто читает | Кто пишет |
|---|---|---|---|---|
| `users` | Пользователи: профили, роли, настройки | `uid` из Authentication | владелец, admin | владелец (кроме роли), admin (роль) |
| `products` | Основные сущности: каталог товаров | авто | все | admin; покупатель — только `stock` при заказе и рейтинг при отзыве |
| `orders` | Действия: история заказов | авто | владелец, admin | владелец создаёт / отменяет новый, admin меняет статус |
| `reviews` | Действия: отзывы и оценки | `productId_uid` | все | автор, admin (удаление — модерация) |
| `carts` | Активные действия: корзина | `uid` | владелец | владелец |

## ER-диаграмма

```mermaid
erDiagram
    USERS ||--o| CARTS : "имеет корзину"
    USERS ||--o{ ORDERS : "оформляет"
    USERS ||--o{ REVIEWS : "пишет"
    PRODUCTS ||--o{ REVIEWS : "получает"
    PRODUCTS }o--o{ ORDERS : "items (копия name, price)"
    PRODUCTS }o--o{ CARTS : "items (копия name, price)"

    USERS {
        string uid PK
        string email
        string displayName
        string phone
        string address
        string role "user | admin"
        map settings "theme, newsletter"
        timestamp createdAt
    }
    PRODUCTS {
        string id PK
        string name
        string nameLower "для поиска по началу названия"
        string description
        string category
        string brand
        array tags
        number price
        number oldPrice
        int stock
        string image "эмодзи"
        array keywords "префиксы слов для поиска"
        number rating "средняя оценка (дубль)"
        int ratingCount
        number ratingSum
        string lastOrderId "служебное, для правил"
        timestamp createdAt
    }
    CARTS {
        string uid PK
        map items "productId -> qty, name, price, image"
        timestamp updatedAt
    }
    ORDERS {
        string id PK
        string userId FK
        string userEmail
        string userName
        map items "productId -> name, price, qty"
        int itemsCount
        number total
        string status "new|confirmed|shipped|done|cancelled"
        string phone
        string address
        string comment
        timestamp createdAt
    }
    REVIEWS {
        string id PK "productId_uid"
        string productId FK
        string productName
        string userId FK
        string userName
        int rating "1..5"
        string text
        timestamp createdAt
    }
```

## Документы подробно

### `users/{uid}`
```json
{
  "email": "user@mail.kz",
  "displayName": "Юрий",
  "phone": "+7 701 000 00 00",
  "address": "Алматы, ул. Абая, 1",
  "role": "user",
  "settings": { "theme": "dark", "newsletter": false },
  "createdAt": "Timestamp", "updatedAt": "Timestamp"
}
```

### `products/{id}`
```json
{
  "name": "Беспроводная мышь Logi M240", "nameLower": "беспроводная мышь logi m240",
  "description": "Тихие клики, Bluetooth…", "category": "Периферия", "brand": "Logitech",
  "tags": ["беспроводная", "тихая"], "price": 7990, "oldPrice": 9490, "stock": 25, "image": "🖱️",
  "keywords": ["бе", "бес", "беспроводная", "мы", "мыш", "мышь", "lo", "log", "logi", "..."],
  "rating": 4.5, "ratingSum": 9, "ratingCount": 2,
  "createdAt": "Timestamp", "updatedAt": "Timestamp"
}
```

### `carts/{uid}` — активные действия
```json
{ "items": { "<productId>": { "qty": 2, "name": "…", "price": 7990, "image": "🖱️", "category": "Периферия" } },
  "updatedAt": "Timestamp" }
```

### `orders/{id}` — история
```json
{
  "userId": "<uid>", "userEmail": "user@mail.kz", "userName": "Юрий",
  "items": { "<productId>": { "name": "…", "price": 7990, "qty": 2, "image": "🖱️" } },
  "itemsCount": 2, "total": 15980, "status": "new",
  "phone": "+7…", "address": "…", "comment": "",
  "createdAt": "Timestamp", "updatedAt": "Timestamp"
}
```

### `reviews/{productId_uid}`
```json
{ "productId": "…", "productName": "…", "userId": "…", "userName": "Юрий",
  "rating": 5, "text": "Отличная мышь", "createdAt": "Timestamp", "updatedAt": "Timestamp" }
```

## Жизненный цикл действий

```mermaid
flowchart LR
    A[Каталог] -->|Добавить в корзину| B[(carts/uid)]
    B -->|Оформить заказ — транзакция| C[(orders)]
    C -->|списание stock| D[(products)]
    C --> E{Статус}
    E -->|admin| F[confirmed → shipped → done]
    E -->|покупатель или admin| G[cancelled — товар возвращается на склад]
```

После оформления заказа корзина удаляется, а заказ появляется в «Истории» личного кабинета.

## Оптимизация

| Приём | Где | Зачем |
|---|---|---|
| **Денормализация** | `orders.items`, `carts.items` хранят копию `name/price/image`; `reviews.userName/productName` | история и корзина отображаются без чтения каждого товара; цена в заказе фиксируется на момент покупки |
| **Агрегаты в документе** | `products.rating/ratingSum/ratingCount` | сортировка каталога по рейтингу без чтения отзывов; обновляются транзакцией |
| **Поисковый индекс** `keywords` | `products` | поиск запросом `array-contains` вместо загрузки всего каталога |
| **Пагинация** | каталог (`limit` + «Показать ещё»), похожие товары, админ-таблицы (`startAfter`), заказы, отзывы | читаем только нужную порцию документов |
| **Агрегирующие запросы** | админка: `getCountFromServer`, `getAggregateFromServer(sum)` | статистика без загрузки документов (1 чтение на 1000 документов) |
| **Локальный кэш** | `persistentLocalCache` + `persistentMultipleTabManager` | повторные чтения из IndexedDB, работа офлайн |
| **Составные индексы** | `firestore.indexes.json` | быстрые запросы «фильтр + сортировка» |
| **Исключение из индексации** | `products.description` | длинный текст не индексируется — экономия места и записи |
| **debounce поиска** | `index.js` | запрос отправляется через 350 мс после ввода, а не на каждую букву |
| **writeBatch** | загрузка демо-данных | 30 товаров одной операцией |

> О `select()`: проекция полей (`select`) есть только в серверных SDK и REST API,
> в веб-SDK её нет. Вместо неё применена денормализация — списки читают
> «лёгкие» документы, где уже есть всё нужное для отображения.

## Составные индексы

| Коллекция | Поля | Запрос |
|---|---|---|
| products | `category ↑`, `createdAt ↓` / `price ↑` / `price ↓` / `rating ↓` | каталог с фильтром по категории |
| products | `keywords (array-contains)`, `createdAt ↓` / `price ↑` / `price ↓` / `rating ↓` | поиск |
| products | `category ↑`, `keywords (array-contains)`, + та же сортировка | поиск внутри категории |
| orders | `userId ↑`, `createdAt ↓` | история заказов пользователя |
| orders | `status ↑`, `createdAt ↓` | админ: фильтр заказов по статусу |
| reviews | `productId ↑`, `createdAt ↓` | отзывы товара |
| reviews | `userId ↑`, `createdAt ↓` | «Мои отзывы» |

## Безопасность (кратко)

Полные правила — в [`firestore.rules`](../firestore.rules). Принципы:

- по умолчанию всё запрещено (`match /{document=**} { allow read, write: if false; }`);
- роль берётся из `users/{uid}.role`; при регистрации разрешена только роль `user`;
  изменить роль может только `admin` (и не самому себе);
- товары меняет только `admin`, данные проверяются (`validProduct`);
- покупатель может уменьшить `stock` товара **ровно** на количество из заказа,
  создаваемого в той же транзакции (`getAfter`), и вернуть его при отмене своего нового заказа;
- агрегаты рейтинга меняются только синхронно с отзывом (проверка дельты через `get`/`getAfter`);
- заказы и корзину видит только владелец (и `admin` — заказы); удалять заказы нельзя.
