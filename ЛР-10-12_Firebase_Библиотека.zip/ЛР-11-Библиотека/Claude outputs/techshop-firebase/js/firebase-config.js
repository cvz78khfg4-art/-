/**
 * Конфигурация веб-приложения Firebase «TechShop Web» (проект techshop-practice).
 * Эти ключи публичные по замыслу Firebase: доступ к данным ограничивают
 * правила безопасности (firestore.rules), а не секретность apiKey.
 */
export const firebaseConfig = {
  apiKey: "AIzaSyBgX68hAyTxeQNZVwxmaDmRcUfG-QTH8b4",
  authDomain: "techshop-practice.firebaseapp.com",
  projectId: "techshop-practice",
  storageBucket: "techshop-practice.firebasestorage.app",
  messagingSenderId: "78842431071",
  appId: "1:78842431071:web:b043589e75a602590ffdea"
};
