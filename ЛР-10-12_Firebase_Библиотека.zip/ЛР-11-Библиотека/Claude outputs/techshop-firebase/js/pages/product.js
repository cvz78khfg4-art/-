/**
 * Детальная страница товара: информация (onSnapshot — остаток и цена в реальном
 * времени), добавление в корзину, отзывы с оценкой (создание/редактирование
 * в транзакции), похожие товары с курсорной пагинацией.
 */
import { initPage, session, onSession } from "../core/session.js";
import { $, esc, money, catStyle, stockPill, stars, errorText, toast, fmtDate, qs, busy, plural } from "../core/ui.js";
import { productCard } from "../core/cards.js";
import { watchProduct, similarPage } from "../services/products.js";
import { addToCart, watchCart, MAX_QTY } from "../services/cart.js";
import { watchProductReviews, saveReview, deleteReview, reviewId } from "../services/reviews.js";

initPage({ active: "catalog" });

const id = qs("id");
let product = null, inCart = 0, unsubCart = null;
let reviewsCount = 5, unsubReviews = null, reviews = [];
let similarCursor = null, similarLoaded = false;

if (!id) showMissing();
else watchProduct(id, (p) => {
  if (!p) return showMissing();
  const first = !product;
  product = p;
  renderProduct();
  renderReviewSummary();
  if (first) { startReviews(); loadSimilar(); }
}, (e) => { $("#product").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`; });

function showMissing() {
  $("#product").innerHTML = `<div class="empty"><div class="big">🤷</div><h2>Товар не найден</h2><p>Возможно, он был удалён.</p><a class="btn btn-primary" href="index.html">В каталог</a></div>`;
  $("#reviews-section").classList.add("hidden");
  $("#similar-section").classList.add("hidden");
}

// Сколько этого товара уже лежит в корзине (реальное время)
onSession((s) => {
  unsubCart?.(); unsubCart = null; inCart = 0;
  if (s.user) unsubCart = watchCart(s.user.uid, (items) => { inCart = items[id]?.qty || 0; renderProduct(); });
  renderProduct(); renderReviewForm();
});

function renderProduct() {
  if (!product) return;
  const p = product, s = catStyle(p.category);
  document.title = `${p.name} — TechShop`;
  $("#bc-cat").textContent = p.category;
  $("#bc-cat").href = "index.html?cat=" + encodeURIComponent(p.category);
  $("#bc-name").textContent = p.name;
  const max = Math.min(p.stock, MAX_QTY) - inCart;
  const discount = p.oldPrice > p.price ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;

  $("#product").innerHTML = `
    <div class="detail">
      <div class="detail-media" style="--c1:${s.c1};--c2:${s.c2}">
        ${discount ? `<span class="pill pill-danger">−${discount}%</span>` : ""}${esc(p.image || s.emoji)}
      </div>
      <div class="detail-info">
        <span class="card-cat">${esc(p.category)}${p.brand ? " · " + esc(p.brand) : ""}</span>
        <h1>${esc(p.name)}</h1>
        <a href="#reviews-section" class="rating" style="text-decoration:none"><span class="stars">${stars(p.rating)}</span> ${p.ratingCount ? `${p.rating} · ${p.ratingCount} ${plural(p.ratingCount, "отзыв", "отзыва", "отзывов")}` : "Нет отзывов — будьте первым"}</a>
        <div class="detail-price">${money(p.price)}${discount ? `<span class="old-price" style="font-size:18px">${money(p.oldPrice)}</span>` : ""}</div>
        <div>${stockPill(p.stock)} <span class="muted" style="font-size:13px;margin-left:6px">на складе: ${p.stock} шт. · обновляется в реальном времени</span></div>
        <div class="detail-actions">
          ${p.stock <= 0
            ? `<button class="btn" disabled>Нет в наличии</button>`
            : max <= 0
              ? `<a class="btn btn-primary" href="cart.html">✓ В корзине (${inCart}) — перейти</a>`
              : `<div class="stepper"><button id="q-dec">−</button><span id="q-val">1</span><button id="q-inc">+</button></div>
                 <button class="btn btn-primary" id="add-btn">🛒 Добавить в корзину</button>
                 ${inCart ? `<a class="btn" href="cart.html">В корзине: ${inCart}</a>` : ""}`}
        </div>
        ${p.description ? `<p style="white-space:pre-wrap">${esc(p.description)}</p>` : ""}
        <dl class="kv">
          <dt>Категория</dt><dd>${esc(p.category)}</dd>
          ${p.brand ? `<dt>Бренд</dt><dd>${esc(p.brand)}</dd>` : ""}
          <dt>Артикул</dt><dd>${esc(p.id.slice(0, 8).toUpperCase())}</dd>
          ${p.tags?.length ? `<dt>Теги</dt><dd><div class="tags">${p.tags.map((t) => `<span class="tag">#${esc(t)}</span>`).join("")}</div></dd>` : ""}
        </dl>
      </div>
    </div>`;

  const add = $("#add-btn");
  if (!add) return;
  let qty = 1;
  const sync = () => { $("#q-val").textContent = qty; $("#q-dec").disabled = qty <= 1; $("#q-inc").disabled = qty >= max; };
  $("#q-dec").onclick = () => { qty = Math.max(1, qty - 1); sync(); };
  $("#q-inc").onclick = () => { qty = Math.min(max, qty + 1); sync(); };
  sync();
  add.onclick = () => {
    if (!session.user) return location.href = "auth.html?next=" + encodeURIComponent("product.html?id=" + id);
    busy(add, async () => {
      try { await addToCart(session.user.uid, product, qty); toast(`🛒 Добавлено: ${qty} шт.`); }
      catch (e) { toast(e.code === "limit" ? e.message : "Ошибка: " + errorText(e), true); }
    });
  };
}

/* ------------------------- Отзывы ------------------------- */
function renderReviewSummary() {
  $("#reviews-section").classList.remove("hidden");
  $("#avg-rating").textContent = product.ratingCount ? product.rating.toFixed(1) : "—";
  $("#avg-stars").textContent = stars(product.rating);
  $("#avg-count").textContent = product.ratingCount ? `${product.ratingCount} ${plural(product.ratingCount, "оценка", "оценки", "оценок")}` : "Оценок пока нет";
}

function startReviews() {
  unsubReviews?.();
  unsubReviews = watchProductReviews(id, reviewsCount, ({ items, hasMore }) => {
    reviews = items;
    $("#reviews").innerHTML = items.length ? items.map((r) => `
      <div class="review">
        <div class="review-head">
          <div><b>${esc(r.userName)}</b> <span class="stars">${stars(r.rating)}</span></div>
          <span class="muted" style="font-size:12px">${fmtDate(r.createdAt)}${r.updatedAt?.seconds !== r.createdAt?.seconds ? " · изменён" : ""}</span>
        </div>
        <p>${esc(r.text)}</p>
        ${session.user && (r.userId === session.user.uid || session.role === "admin")
          ? `<div class="gap-row" style="margin-top:8px">
              ${r.userId === session.user.uid ? `<button class="btn btn-sm" data-edit>✏️ Изменить</button>` : ""}
              <button class="btn btn-sm btn-danger" data-del="${esc(r.id)}">🗑 Удалить${r.userId !== session.user.uid ? " (модерация)" : ""}</button>
            </div>` : ""}
      </div>`).join("")
      : `<div class="empty" style="padding:30px"><div class="big">💬</div>Отзывов ещё нет</div>`;
    $("#more-reviews").classList.toggle("hidden", !hasMore);
    renderReviewForm();
  }, (e) => { $("#reviews").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`; });
}
$("#more-reviews").onclick = () => { reviewsCount += 5; startReviews(); };

$("#reviews").addEventListener("click", async (e) => {
  if (e.target.closest("[data-edit]")) { $("#review-text")?.focus(); $("#review-form-box").scrollIntoView({ behavior: "smooth", block: "center" }); return; }
  const del = e.target.closest("[data-del]")?.dataset.del;
  if (!del || !confirm("Удалить отзыв?")) return;
  try { await deleteReview(del); toast("Отзыв удалён"); } catch (err) { toast("Ошибка: " + errorText(err), true); }
});

function renderReviewForm() {
  const box = $("#review-form-box");
  if (!product) return;
  if (!session.user) { box.innerHTML = `<p class="muted" style="font-size:14px">Чтобы оставить отзыв, <a href="auth.html?next=${encodeURIComponent("product.html?id=" + id)}">войдите</a>.</p>`; return; }
  const mine = reviews.find((r) => r.id === reviewId(id, session.user.uid));
  if (box.dataset.for === (mine ? mine.id + mine.updatedAt?.seconds : "new")) return; // не сбрасываем ввод
  box.dataset.for = mine ? mine.id + mine.updatedAt?.seconds : "new";
  box.innerHTML = `
    <form id="review-form">
      <b>${mine ? "Ваш отзыв" : "Оставить отзыв"}</b>
      <div class="star-input" style="margin:8px 0">
        ${[5, 4, 3, 2, 1].map((n) => `<input type="radio" name="rating" id="st${n}" value="${n}" ${mine?.rating === n ? "checked" : ""}><label for="st${n}" title="${n}">★</label>`).join("")}
      </div>
      <textarea class="textarea" id="review-text" maxlength="1000" placeholder="Расскажите о товаре" required>${esc(mine?.text || "")}</textarea>
      <div class="form-error hidden" id="review-error" style="margin-top:10px"></div>
      <button class="btn btn-primary btn-block mt" id="review-submit">${mine ? "Сохранить изменения" : "Опубликовать"}</button>
    </form>`;
  $("#review-form").onsubmit = (e) => {
    e.preventDefault();
    const rating = Number(new FormData(e.target).get("rating"));
    const text = $("#review-text").value.trim();
    const err = $("#review-error");
    if (!rating) return (err.textContent = "Поставьте оценку от 1 до 5", err.classList.remove("hidden"));
    if (text.length < 3) return (err.textContent = "Напишите хотя бы пару слов", err.classList.remove("hidden"));
    busy($("#review-submit"), async () => {
      try { await saveReview(session.user, session.profile, product, { rating, text }); toast(mine ? "Отзыв обновлён" : "Спасибо за отзыв!"); box.dataset.for = ""; }
      catch (e2) { err.textContent = errorText(e2); err.classList.remove("hidden"); }
    });
  };
}

/* ------------------------- Похожие товары ------------------------- */
async function loadSimilar() {
  try {
    const { items, cursor, hasMore } = await similarPage(product.category, similarCursor, 4);
    similarCursor = cursor;
    const list = items.filter((p) => p.id !== id);
    if (!similarLoaded && !list.length && !hasMore) return;
    similarLoaded = true;
    $("#similar-section").classList.remove("hidden");
    $("#similar").insertAdjacentHTML("beforeend", list.map(productCard).join(""));
    $("#more-similar").classList.toggle("hidden", !hasMore);
  } catch (e) { console.error("similar", e); }
}
$("#more-similar").onclick = (e) => busy(e.target, loadSimilar);
