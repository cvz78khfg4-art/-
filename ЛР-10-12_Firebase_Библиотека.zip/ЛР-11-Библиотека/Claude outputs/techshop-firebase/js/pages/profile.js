/**
 * Личный кабинет: история заказов со статусами в реальном времени (onSnapshot),
 * отмена нового заказа, мои отзывы (редактирование/удаление), профиль, настройки,
 * смена пароля по email.
 */
import { initPage, onSession } from "../core/session.js";
import {
  $, $$, esc, money, fmtDate, fmtDateTime, statusPill, ORDER_STATUS, stars, errorText, toast,
  busy, showErr, hideErr, openModal, closeModal, applyTheme, catStyle, qs
} from "../core/ui.js";
import { auth, sendPasswordResetEmail } from "../firebase.js";
import { watchMyOrders, setOrderStatus } from "../services/orders.js";
import { watchMyReviews, saveReview, deleteReview } from "../services/reviews.js";
import { updateMyProfile } from "../services/users.js";

const s = await initPage({ active: "profile", requireAuth: true });
const uid = s.user.uid;

/* ---------- шапка профиля (обновляется при каждом изменении профиля) ---------- */
onSession(({ profile, role, user }) => {
  if (!user || !profile) return;
  const name = profile.displayName || user.email;
  $("#avatar").textContent = name.trim()[0].toUpperCase();
  $("#p-name").textContent = profile.displayName || "Имя не указано";
  $("#p-email").textContent = user.email;
  $("#p-date").textContent = fmtDate(profile.createdAt);
  $("#p-role").textContent = role === "admin" ? "🛠 Администратор" : "🛍 Покупатель";
  $("#p-role").className = "pill " + (role === "admin" ? "pill-danger" : "pill-info");
});

/* ---------- вкладки (#orders, #reviews, #profile, #settings) ---------- */
function showTab(name) {
  if (!$("#tab-" + name)) name = "orders";
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  $$(".tab-pane").forEach((p) => p.classList.toggle("hidden", p.id !== "tab-" + name));
  history.replaceState(null, "", location.pathname + location.search + "#" + name);
}
$("#tabs").onclick = (e) => { const t = e.target.closest("[data-tab]"); if (t) showTab(t.dataset.tab); };
showTab(location.hash.slice(1));

/* ---------- история заказов ---------- */
let ordersCount = 10, orders = [], filter = "all", unsubOrders = null;
const highlight = qs("order");

function subscribeOrders() {
  unsubOrders?.();
  unsubOrders = watchMyOrders(uid, ordersCount, ({ items, hasMore }) => {
    orders = items;
    renderOrders();
    $("#more-orders").classList.toggle("hidden", !hasMore);
    const active = items.filter((o) => ["new", "confirmed", "shipped"].includes(o.status));
    $("#st-orders").textContent = items.length + (hasMore ? "+" : "");
    $("#st-active").textContent = active.length;
    $("#st-spent").textContent = money(items.filter((o) => o.status !== "cancelled").reduce((n, o) => n + o.total, 0));
  }, (e) => { $("#orders").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`; });
}
$("#more-orders").onclick = () => { ordersCount += 10; subscribeOrders(); };

function renderOrders() {
  const counts = { all: orders.length };
  orders.forEach((o) => (counts[o.status] = (counts[o.status] || 0) + 1));
  $("#order-filter").innerHTML = [["all", "Все"], ...Object.entries(ORDER_STATUS).map(([k, v]) => [k, v.text])]
    .filter(([k]) => k === "all" || counts[k])
    .map(([k, t]) => `<button class="chip ${k === filter ? "active" : ""}" data-f="${k}">${t} · ${counts[k] || 0}</button>`).join("");

  const list = orders.filter((o) => filter === "all" || o.status === filter);
  $("#orders").innerHTML = list.length ? list.map((o) => `
    <div class="order" ${o.id === highlight ? 'style="border-color:var(--accent);box-shadow:0 0 0 4px var(--accent-soft)"' : ""}>
      <div class="order-head">
        <div><b>Заказ №${esc(o.id.slice(0, 6).toUpperCase())}</b> <span class="muted" style="font-size:13px">· ${fmtDateTime(o.createdAt)}</span></div>
        ${statusPill(o.status)}
      </div>
      <ul class="order-items">${Object.entries(o.items || {}).map(([pid, i]) =>
        `<li><a href="product.html?id=${encodeURIComponent(pid)}" style="color:inherit">${esc(i.image || catStyle(i.category).emoji)} ${esc(i.name)} × ${i.qty}</a><span>${money(i.price * i.qty)}</span></li>`).join("")}</ul>
      <div class="muted" style="font-size:13px;margin-top:6px">📍 ${esc(o.address)} · 📞 ${esc(o.phone)}</div>
      <div class="order-foot"><b>Итого: ${money(o.total)}</b>
        ${o.status === "new" ? `<button class="btn btn-sm btn-danger" data-cancel="${o.id}">Отменить заказ</button>` : ""}</div>
    </div>`).join("")
    : `<div class="empty"><div class="big">📦</div>Заказов пока нет<br><br><a class="btn btn-primary" href="index.html">В каталог</a></div>`;
}
$("#order-filter").onclick = (e) => { const b = e.target.closest("[data-f]"); if (b) { filter = b.dataset.f; renderOrders(); } };
$("#orders").onclick = async (e) => {
  const id = e.target.closest("[data-cancel]")?.dataset.cancel;
  if (!id || !confirm("Отменить заказ? Товары вернутся на склад.")) return;
  try { await setOrderStatus(id, "cancelled"); toast("Заказ отменён"); } catch (err) { toast(err.code ? errorText(err) : err.message, true); }
};
subscribeOrders();

/* ---------- мои отзывы ---------- */
let myReviews = [], editing = null;
watchMyReviews(uid, (items) => {
  myReviews = items;
  $("#st-reviews").textContent = items.length;
  $("#my-reviews").innerHTML = items.length ? items.map((r) => `
    <div class="order">
      <div class="order-head">
        <a href="product.html?id=${encodeURIComponent(r.productId)}" style="color:inherit"><b>${esc(r.productName)}</b></a>
        <span class="stars">${stars(r.rating)}</span>
      </div>
      <p style="margin:8px 0;white-space:pre-wrap">${esc(r.text)}</p>
      <div class="order-foot"><span class="muted" style="font-size:13px">${fmtDate(r.createdAt)}</span>
        <div class="gap-row"><button class="btn btn-sm" data-edit="${esc(r.id)}">✏️ Изменить</button><button class="btn btn-sm btn-danger" data-del="${esc(r.id)}">🗑 Удалить</button></div></div>
    </div>`).join("")
    : `<div class="empty"><div class="big">💬</div>Вы ещё не оставляли отзывов</div>`;
}, (e) => { $("#my-reviews").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`; });

$("#my-reviews").onclick = async (e) => {
  const del = e.target.closest("[data-del]")?.dataset.del;
  const edit = e.target.closest("[data-edit]")?.dataset.edit;
  if (del && confirm("Удалить отзыв?")) {
    try { await deleteReview(del); toast("Отзыв удалён"); } catch (err) { toast(errorText(err), true); }
  }
  if (edit) {
    editing = myReviews.find((r) => r.id === edit);
    openModal("review-modal");
    $("#rm-product").textContent = editing.productName;
    $("#rm-text").value = editing.text;
    $(`#r${editing.rating}`).checked = true;
  }
};
$("#review-form").onsubmit = (e) => {
  e.preventDefault();
  const rating = Number(new FormData(e.target).get("rating"));
  const text = $("#rm-text").value.trim();
  if (!rating || text.length < 3) return showErr($("#rm-error"), "Поставьте оценку и напишите текст");
  busy($("#rm-save"), async () => {
    try {
      await saveReview(s.user, s.profile, { id: editing.productId, name: editing.productName }, { rating, text });
      closeModal("review-modal"); toast("Отзыв обновлён");
    } catch (err) { showErr($("#rm-error"), errorText(err)); }
  });
};

/* ---------- профиль ---------- */
$("#f-name").value = s.profile?.displayName || "";
$("#f-phone").value = s.profile?.phone || "";
$("#f-address").value = s.profile?.address || "";
$("#profile-form").onsubmit = (e) => {
  e.preventDefault();
  const box = $("#profile-error"); hideErr(box);
  const phone = $("#f-phone").value.trim();
  if (phone && !/^[+\d][\d\s()-]{9,}$/.test(phone)) return showErr(box, "Некорректный номер телефона");
  busy($("#profile-save"), async () => {
    try { await updateMyProfile(uid, { displayName: $("#f-name").value.trim(), phone, address: $("#f-address").value.trim() }); toast("✅ Профиль сохранён"); }
    catch (err) { showErr(box, errorText(err)); }
  });
};

/* ---------- настройки ---------- */
$("#s-theme").value = s.profile?.settings?.theme || "light";
$("#s-news").checked = !!s.profile?.settings?.newsletter;
$("#settings-form").onsubmit = (e) => {
  e.preventDefault();
  const settings = { theme: $("#s-theme").value, newsletter: $("#s-news").checked };
  busy($("#settings-save"), async () => {
    try { await updateMyProfile(uid, { settings }); applyTheme(settings.theme); toast("Настройки сохранены"); }
    catch (err) { toast(errorText(err), true); }
  });
};
$("#reset-btn").onclick = (e) => busy(e.target, async () => {
  try { await sendPasswordResetEmail(auth, s.user.email); toast("📧 Письмо отправлено на " + s.user.email); }
  catch (err) { toast(errorText(err), true); }
});
