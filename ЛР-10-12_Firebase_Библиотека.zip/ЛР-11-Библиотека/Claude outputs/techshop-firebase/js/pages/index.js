/**
 * Главная страница: каталог с пагинацией «Показать ещё», поиском (запрос
 * array-contains к Firestore), фильтром по категориям, сортировкой
 * и обновлением в реальном времени (onSnapshot).
 */
import { initPage } from "../core/session.js";
import { $, esc, errorText, skeletonCards, CATEGORIES, plural } from "../core/ui.js";
import { productCard } from "../core/cards.js";
import { watchCatalog, SORTS } from "../services/products.js";
import { matchesAll } from "../services/search.js";

initPage({ active: "catalog" });

const PAGE = 12;
// Состояние фильтров хранится в URL — ссылку на подборку можно скопировать
const params = new URLSearchParams(location.search);
const state = {
  category: params.get("cat") || "all",
  search: params.get("q") || "",
  sort: SORTS[params.get("sort")] ? params.get("sort") : "new",
  count: PAGE
};
let unsubscribe = null;

$("#search").value = state.search;
$("#sort").innerHTML = Object.entries(SORTS).map(([k, s]) => `<option value="${k}" ${k === state.sort ? "selected" : ""}>${s.label}</option>`).join("");

function renderChips() {
  const cats = ["all", ...Object.keys(CATEGORIES)];
  $("#chips").innerHTML = cats.map((c) =>
    `<button class="chip ${c === state.category ? "active" : ""}" data-cat="${esc(c)}">${c === "all" ? "Все" : CATEGORIES[c].emoji + " " + esc(c)}</button>`).join("");
}

function syncUrl() {
  const p = new URLSearchParams();
  if (state.category !== "all") p.set("cat", state.category);
  if (state.search) p.set("q", state.search);
  if (state.sort !== "new") p.set("sort", state.sort);
  history.replaceState(null, "", location.pathname + (p.toString() ? "?" + p : ""));
}

/** (Пере)подписка на каталог с текущими фильтрами */
function subscribe(resetCount = true) {
  if (resetCount) { state.count = PAGE; $("#grid").innerHTML = skeletonCards(8); }
  unsubscribe?.();
  $("#more-btn").disabled = true;
  unsubscribe = watchCatalog(state, ({ items, hasMore }) => {
    // если в запросе несколько слов — остальные проверяем на клиенте
    const list = state.search.trim().includes(" ") ? items.filter((p) => matchesAll(p, state.search)) : items;
    $("#hs-shown").textContent = list.length;
    $("#status").textContent = state.search
      ? `По запросу «${state.search}» ${list.length ? `найдено ${list.length}${hasMore ? "+" : ""} ${plural(list.length, "товар", "товара", "товаров")}` : "ничего не найдено"}`
      : `Показано ${list.length} ${plural(list.length, "товар", "товара", "товаров")}${hasMore ? " — ниже есть ещё" : ""}`;
    $("#grid").innerHTML = list.length
      ? list.map(productCard).join("")
      : `<div class="empty" style="grid-column:1/-1"><div class="big">🔎</div>Ничего не найдено. Попробуйте другой запрос или категорию.</div>`;
    $("#more-btn").classList.toggle("hidden", !hasMore);
    $("#more-btn").disabled = false;
  }, (e) => {
    console.error(e);
    $("#grid").innerHTML = `<div class="error-box" style="grid-column:1/-1">Ошибка загрузки каталога: ${esc(errorText(e))}</div>`;
  });
}

$("#chips").addEventListener("click", (e) => {
  const b = e.target.closest("[data-cat]"); if (!b) return;
  state.category = b.dataset.cat; renderChips(); syncUrl(); subscribe();
});
$("#sort").addEventListener("change", (e) => { state.sort = e.target.value; syncUrl(); subscribe(); });

let timer;
$("#search").addEventListener("input", (e) => {
  clearTimeout(timer);
  // debounce: не отправляем запрос на каждую букву
  timer = setTimeout(() => { state.search = e.target.value.trim(); syncUrl(); subscribe(); }, 350);
});

$("#more-btn").addEventListener("click", () => { state.count += PAGE; subscribe(false); });

renderChips();
subscribe();
