/**
 * Корзина: управление активными действиями (кол-во, удаление, очистка)
 * и финализация — оформление заказа. После оформления корзина очищается,
 * а заказ появляется в «Истории» личного кабинета.
 */
import { initPage } from "../core/session.js";
import { $, esc, money, catStyle, errorText, toast, busy, showErr, hideErr, plural } from "../core/ui.js";
import { watchCart, setQty, removeFromCart, clearCart, checkout, rememberContacts, MAX_QTY } from "../services/cart.js";

const s = await initPage({ active: "cart", requireAuth: true });
const uid = s.user.uid;
let items = {};

// Подставляем контакты из профиля
$("#phone").value = s.profile?.phone || "";
$("#address").value = s.profile?.address || "";

watchCart(uid, (data) => { items = data; render(); }, (e) => {
  $("#cart-list").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`;
});

function render() {
  const entries = Object.entries(items);
  const count = entries.reduce((n, [, i]) => n + i.qty, 0);
  const total = entries.reduce((n, [, i]) => n + i.qty * i.price, 0);
  $("#sum-count").textContent = count;
  $("#sum-total").textContent = money(total);
  $("#checkout-btn").disabled = !entries.length;
  $("#clear-btn").classList.toggle("hidden", !entries.length);

  if (!entries.length) {
    $("#cart-list").innerHTML = `<div class="empty"><div class="big">🛒</div><h3>Корзина пуста</h3><p>Загляните в каталог — там много интересного.</p><a class="btn btn-primary" href="index.html">Перейти в каталог</a></div>`;
    return;
  }
  $("#cart-list").innerHTML = `<b>${count} ${plural(count, "товар", "товара", "товаров")}</b>` + entries.map(([id, i]) => {
    const st = catStyle(i.category);
    return `
      <div class="cart-row">
        <a class="cart-thumb" href="product.html?id=${encodeURIComponent(id)}" style="--c1:${st.c1};--c2:${st.c2};text-decoration:none">${esc(i.image || st.emoji)}</a>
        <div class="cart-info"><a href="product.html?id=${encodeURIComponent(id)}" style="color:inherit;text-decoration:none"><b>${esc(i.name)}</b></a><span class="muted cart-price" style="font-size:13px">${money(i.price)} за шт.</span></div>
        <div class="stepper"><button data-dec="${esc(id)}" ${i.qty <= 1 ? "disabled" : ""}>−</button><span>${i.qty}</span><button data-inc="${esc(id)}" ${i.qty >= MAX_QTY ? "disabled" : ""}>+</button></div>
        <b class="cart-sum" style="min-width:90px;text-align:right">${money(i.price * i.qty)}</b>
        <button class="btn btn-ghost btn-icon btn-sm btn-danger" data-del="${esc(id)}" title="Удалить">✕</button>
      </div>`;
  }).join("");
}

$("#cart-list").addEventListener("click", async (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const { inc, dec, del } = b.dataset;
  try {
    if (inc) await setQty(uid, inc, items[inc].qty + 1);
    if (dec) await setQty(uid, dec, items[dec].qty - 1);
    if (del) { await removeFromCart(uid, del); toast("Товар удалён из корзины"); }
  } catch (err) { toast("Ошибка: " + errorText(err), true); }
});

$("#clear-btn").onclick = async () => {
  if (!confirm("Очистить корзину?")) return;
  try { await clearCart(uid); toast("Корзина очищена"); } catch (err) { toast(errorText(err), true); }
};

$("#checkout-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const box = $("#checkout-error"); hideErr(box);
  const form = { phone: $("#phone").value.trim(), address: $("#address").value.trim(), comment: $("#comment").value.trim() };
  if (!/^[+\d][\d\s()-]{9,}$/.test(form.phone)) return showErr(box, "Введите корректный номер телефона");
  if (form.address.length < 5) return showErr(box, "Укажите адрес доставки");
  busy($("#checkout-btn"), async () => {
    try {
      const orderId = await checkout(s.user, s.profile, form);
      if ($("#remember").checked) rememberContacts(uid, form).catch(() => {});
      toast("✅ Заказ оформлен!");
      location.href = "profile.html?order=" + orderId + "#orders";
    } catch (err) { showErr(box, err.code ? errorText(err) : err.message); }
  });
});
