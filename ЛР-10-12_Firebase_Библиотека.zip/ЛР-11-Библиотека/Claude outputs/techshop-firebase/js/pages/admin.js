/**
 * Админ-панель: заказы всех пользователей в реальном времени и смена статусов,
 * CRUD товаров с поиском и курсорной пагинацией, пользователи и роли,
 * модерация отзывов, статистика через агрегирующие запросы (count/sum).
 */
import { initPage, session } from "../core/session.js";
import {
  $, $$, esc, money, fmtDate, fmtDateTime, statusPill, ORDER_STATUS, stars, errorText, toast,
  busy, showErr, hideErr, openModal, closeModal, CATEGORIES, catStyle, stockPill
} from "../core/ui.js";
import {
  adminProductsPage, createProduct, updateProduct, patchProduct, deleteProduct, countProducts, seedProducts
} from "../services/products.js";
import { watchAllOrders, setOrderStatus, orderStats } from "../services/orders.js";
import { usersPage, setRole, countUsers } from "../services/users.js";
import { watchAllReviews, deleteReview, countReviews } from "../services/reviews.js";
import { DEMO_PRODUCTS } from "../demo-data.js";

const s = await initPage({ active: "admin", requireAuth: true, requireAdmin: true });
if (s.role !== "admin") await new Promise(() => {}); // не админ: страница уже заменена сообщением «Доступ запрещён», дальше не выполняем

/* ---------- вкладки ---------- */
function showTab(name) {
  if (!$("#tab-" + name)) name = "orders";
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  $$(".tab-pane").forEach((p) => p.classList.toggle("hidden", p.id !== "tab-" + name));
  history.replaceState(null, "", "#" + name);
  if (name === "products" && !productsLoaded) loadProducts(true);
  if (name === "users" && !usersLoaded) loadUsers(true);
  if (name === "reviews" && !reviewsStarted) startReviews();
}
$("#tabs").onclick = (e) => { const t = e.target.closest("[data-tab]"); if (t) showTab(t.dataset.tab); };

/* ---------- статистика (getCountFromServer / getAggregateFromServer) ---------- */
async function loadStats() {
  try {
    const [products, users, reviews, o] = await Promise.all([countProducts(), countUsers(), countReviews(), orderStats()]);
    $("#st-products").textContent = products;
    $("#st-users").textContent = users;
    $("#st-reviews").textContent = reviews;
    $("#st-orders").textContent = `${o.orders} / ${o.newOrders}`;
    $("#st-revenue").textContent = money(o.revenue);
    if (!products) $("#seed-btn").classList.add("btn-primary");
  } catch (e) { console.error(e); toast("Статистика: " + errorText(e), true); }
}
$("#refresh-stats").onclick = (e) => busy(e.target, loadStats);

/* ---------- заказы (реальное время) ---------- */
let orderFilter = "all", ordersCount = 20, unsubOrders = null, orders = [];
function subscribeOrders() {
  unsubOrders?.();
  unsubOrders = watchAllOrders(orderFilter, ordersCount, ({ items, hasMore }) => {
    orders = items;
    renderOrders();
    $("#more-orders").classList.toggle("hidden", !hasMore);
  }, (e) => { $("#orders").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`; console.error(e); });
}
// Отдельная подписка на новые заказы — бейдж на вкладке
watchAllOrders("new", 99, ({ items }) => {
  $("#new-badge").textContent = items.length;
  $("#new-badge").classList.toggle("hidden", !items.length);
});

const NEXT = {
  new: [["confirmed", "Подтвердить"], ["cancelled", "Отменить"]],
  confirmed: [["shipped", "Отправить"], ["cancelled", "Отменить"]],
  shipped: [["done", "Доставлен"]]
};
function renderOrders() {
  $("#order-filter").innerHTML = [["all", "Все"], ...Object.entries(ORDER_STATUS).map(([k, v]) => [k, v.text])]
    .map(([k, t]) => `<button class="chip ${k === orderFilter ? "active" : ""}" data-f="${k}">${t}</button>`).join("");
  $("#orders").innerHTML = orders.length ? orders.map((o) => `
    <div class="order">
      <div class="order-head">
        <div><b>№${esc(o.id.slice(0, 6).toUpperCase())}</b> <span class="muted" style="font-size:13px">· ${fmtDateTime(o.createdAt)} · ${esc(o.userName || "")} ${esc(o.userEmail)}</span></div>
        ${statusPill(o.status)}
      </div>
      <ul class="order-items">${Object.values(o.items || {}).map((i) => `<li><span>${esc(i.name)} × ${i.qty}</span><span>${money(i.price * i.qty)}</span></li>`).join("")}</ul>
      <div class="muted" style="font-size:13px;margin-top:6px">📍 ${esc(o.address)} · 📞 ${esc(o.phone)}${o.comment ? " · 💬 " + esc(o.comment) : ""}</div>
      <div class="order-foot"><b>Итого: ${money(o.total)}</b>
        <div class="gap-row">${(NEXT[o.status] || []).map(([st, t]) =>
          `<button class="btn btn-sm ${st === "cancelled" ? "btn-danger" : "btn-primary"}" data-order="${o.id}" data-status="${st}">${t}</button>`).join("")}</div></div>
    </div>`).join("") : `<div class="empty"><div class="big">📭</div>Заказов нет</div>`;
}
$("#order-filter").onclick = (e) => { const b = e.target.closest("[data-f]"); if (b) { orderFilter = b.dataset.f; ordersCount = 20; subscribeOrders(); } };
$("#more-orders").onclick = () => { ordersCount += 20; subscribeOrders(); };
$("#orders").onclick = (e) => {
  const b = e.target.closest("[data-status]"); if (!b) return;
  if (b.dataset.status === "cancelled" && !confirm("Отменить заказ? Товары вернутся на склад.")) return;
  busy(b, async () => {
    try { await setOrderStatus(b.dataset.order, b.dataset.status); toast("Статус: " + ORDER_STATUS[b.dataset.status].text); }
    catch (err) { toast(err.code ? errorText(err) : err.message, true); }
  });
};

/* ---------- товары: CRUD + поиск + курсорная пагинация ---------- */
let productsLoaded = false, pCursor = null, products = [], pTerm = "";
async function loadProducts(reset) {
  productsLoaded = true;
  if (reset) { pCursor = null; products = []; $("#products-table").innerHTML = `<tr><td colspan="6" class="center"><span class="spinner"></span></td></tr>`; }
  try {
    const page = await adminProductsPage({ term: pTerm, cursor: pCursor });
    pCursor = page.cursor;
    products = reset ? page.items : [...products, ...page.items];
    renderProducts();
    $("#more-products").classList.toggle("hidden", !page.hasMore);
  } catch (e) { $("#products-table").innerHTML = `<tr><td colspan="6"><div class="error-box">${esc(errorText(e))}</div></td></tr>`; }
}
function renderProducts() {
  $("#products-table").innerHTML = products.map((p) => `
    <tr>
      <td style="font-size:26px;width:44px">${esc(p.image || catStyle(p.category).emoji)}</td>
      <td><a href="product.html?id=${encodeURIComponent(p.id)}" style="color:inherit"><b>${esc(p.name)}</b></a><div class="muted" style="font-size:12px">${esc(p.category)}${p.brand ? " · " + esc(p.brand) : ""}</div></td>
      <td><input class="input" type="number" min="1" value="${p.price}" data-price="${p.id}"></td>
      <td><div class="gap-row"><input class="input" type="number" min="0" value="${p.stock}" data-stock="${p.id}" style="max-width:80px">${stockPill(p.stock)}</div></td>
      <td><span class="stars">${stars(p.rating)}</span> <span class="muted" style="font-size:12px">${p.ratingCount || 0}</span></td>
      <td><div class="row-actions"><button class="btn btn-sm" data-edit="${p.id}" title="Редактировать">✏️</button><button class="btn btn-sm btn-danger" data-del="${p.id}" title="Удалить">🗑</button></div></td>
    </tr>`).join("") || `<tr><td colspan="6" class="muted center">Товаров нет. Нажмите «Демо-данные», чтобы заполнить каталог.</td></tr>`;
}
let pTimer;
$("#p-search").oninput = (e) => { clearTimeout(pTimer); pTimer = setTimeout(() => { pTerm = e.target.value.trim(); loadProducts(true); }, 350); };
$("#more-products").onclick = (e) => busy(e.target, () => loadProducts(false));

// Быстрое изменение цены и остатка прямо в таблице
$("#products-table").addEventListener("change", async (e) => {
  const id = e.target.dataset.price || e.target.dataset.stock; if (!id) return;
  const val = Math.round(Number(e.target.value));
  const field = e.target.dataset.price ? "price" : "stock";
  if ((field === "price" && !(val > 0)) || (field === "stock" && !(val >= 0))) return toast("Некорректное значение", true);
  try {
    await patchProduct(id, { [field]: val });
    Object.assign(products.find((p) => p.id === id), { [field]: val });
    renderProducts(); toast("💾 Сохранено");
  } catch (err) { toast(errorText(err), true); }
});
$("#products-table").addEventListener("click", async (e) => {
  const edit = e.target.closest("[data-edit]")?.dataset.edit;
  const del = e.target.closest("[data-del]")?.dataset.del;
  if (edit) openProductForm(products.find((p) => p.id === edit));
  if (del) {
    const p = products.find((x) => x.id === del);
    if (!confirm(`Удалить «${p.name}»? Это действие необратимо.`)) return;
    try { await deleteProduct(del); products = products.filter((x) => x.id !== del); renderProducts(); toast("🗑 Товар удалён"); loadStats(); }
    catch (err) { toast(errorText(err), true); }
  }
});

$("#pm-category").innerHTML = Object.keys(CATEGORIES).map((c) => `<option>${esc(c)}</option>`).join("");
let editing = null;
function openProductForm(p = null) {
  editing = p;
  openModal("product-modal");
  $("#pm-title").textContent = p ? "Редактировать товар" : "Новый товар";
  if (p) {
    $("#pm-name").value = p.name; $("#pm-category").value = p.category; $("#pm-brand").value = p.brand || "";
    $("#pm-price").value = p.price; $("#pm-old").value = p.oldPrice || ""; $("#pm-stock").value = p.stock;
    $("#pm-image").value = p.image || ""; $("#pm-tags").value = (p.tags || []).join(", "); $("#pm-desc").value = p.description || "";
  }
}
$("#add-product").onclick = () => openProductForm();
$("#product-form").onsubmit = (e) => {
  e.preventDefault();
  const box = $("#pm-error"); hideErr(box);
  const data = {
    name: $("#pm-name").value, category: $("#pm-category").value, brand: $("#pm-brand").value,
    price: $("#pm-price").value, oldPrice: $("#pm-old").value, stock: Number($("#pm-stock").value),
    image: $("#pm-image").value, tags: $("#pm-tags").value.split(","), description: $("#pm-desc").value
  };
  if (data.name.trim().length < 2) return showErr(box, "Введите название");
  if (!(Number(data.price) > 0) || Number(data.price) > 10_000_000) return showErr(box, "Цена — от 1 до 10 000 000 ₸");
  if ($("#pm-stock").value === "" || !Number.isInteger(data.stock) || data.stock < 0) return showErr(box, "Остаток — целое число от 0");
  if (data.oldPrice && Number(data.oldPrice) <= Number(data.price)) return showErr(box, "Старая цена должна быть больше текущей");
  busy($("#pm-save"), async () => {
    try {
      if (editing) await updateProduct(editing.id, data); else await createProduct(data);
      closeModal("product-modal");
      toast(editing ? "💾 Товар обновлён" : "✨ Товар добавлен");
      loadProducts(true); loadStats();
    } catch (err) { showErr(box, errorText(err)); }
  });
};

$("#seed-btn").onclick = (e) => {
  if (!confirm(`Добавить ${DEMO_PRODUCTS.length} демо-товаров в каталог?`)) return;
  busy(e.target, async () => {
    try { await seedProducts(DEMO_PRODUCTS); toast(`✨ Добавлено ${DEMO_PRODUCTS.length} товаров`); loadProducts(true); loadStats(); }
    catch (err) { toast(errorText(err), true); }
  });
};

/* ---------- пользователи и роли ---------- */
let usersLoaded = false, uCursor = null, users = [];
async function loadUsers(reset) {
  usersLoaded = true;
  if (reset) { uCursor = null; users = []; }
  try {
    const page = await usersPage(uCursor);
    uCursor = page.cursor;
    users = [...users, ...page.items];
    renderUsers();
    $("#more-users").classList.toggle("hidden", !page.hasMore);
  } catch (e) { $("#users-table").innerHTML = `<tr><td colspan="4"><div class="error-box">${esc(errorText(e))}</div></td></tr>`; }
}
function renderUsers() {
  $("#users-table").innerHTML = users.map((u) => `
    <tr>
      <td><b>${esc(u.displayName || "—")}</b><div class="muted" style="font-size:12px">${esc(u.email)}</div></td>
      <td>${esc(u.phone || "—")}</td>
      <td>${fmtDate(u.createdAt)}</td>
      <td>${u.id === session.user.uid
        ? `<span class="pill pill-danger">admin (вы)</span>`
        : `<select class="select" data-role="${u.id}" style="max-width:150px">
            <option value="user" ${u.role !== "admin" ? "selected" : ""}>user</option>
            <option value="admin" ${u.role === "admin" ? "selected" : ""}>admin</option></select>`}</td>
    </tr>`).join("");
}
$("#more-users").onclick = (e) => busy(e.target, () => loadUsers(false));
$("#users-table").addEventListener("change", async (e) => {
  const uid = e.target.dataset.role; if (!uid) return;
  const role = e.target.value;
  if (!confirm(`Назначить роль «${role}»?`)) { renderUsers(); return; }
  try { await setRole(uid, role); users.find((u) => u.id === uid).role = role; toast("Роль изменена"); }
  catch (err) { toast(errorText(err), true); renderUsers(); }
});

/* ---------- модерация отзывов ---------- */
let reviewsStarted = false;
function startReviews() {
  reviewsStarted = true;
  watchAllReviews(50, (items) => {
    $("#reviews").innerHTML = items.length ? items.map((r) => `
      <div class="order">
        <div class="order-head">
          <div><b>${esc(r.userName)}</b> о <a href="product.html?id=${encodeURIComponent(r.productId)}">${esc(r.productName)}</a></div>
          <span class="stars">${stars(r.rating)}</span>
        </div>
        <p style="margin:8px 0;white-space:pre-wrap">${esc(r.text)}</p>
        <div class="order-foot"><span class="muted" style="font-size:13px">${fmtDateTime(r.createdAt)}</span>
          <button class="btn btn-sm btn-danger" data-del="${esc(r.id)}">🗑 Удалить</button></div>
      </div>`).join("") : `<div class="empty"><div class="big">💬</div>Отзывов нет</div>`;
  }, (e) => { $("#reviews").innerHTML = `<div class="error-box">${esc(errorText(e))}</div>`; });
}
$("#reviews").onclick = async (e) => {
  const id = e.target.closest("[data-del]")?.dataset.del;
  if (!id || !confirm("Удалить отзыв как некорректный?")) return;
  try { await deleteReview(id); toast("Отзыв удалён"); loadStats(); } catch (err) { toast(errorText(err), true); }
};

/* ---------- старт ---------- */
renderOrders();
subscribeOrders();
loadStats();
showTab(location.hash.slice(1));
