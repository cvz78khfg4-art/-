/**
 * Авторизация: вход (с выбором сохранения сессии), регистрация (создание
 * профиля с ролью user), восстановление пароля по email.
 */
import {
  auth, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail,
  updateProfile, setPersistence, browserLocalPersistence, browserSessionPersistence
} from "../firebase.js";
import { initPage, onSession } from "../core/session.js";
import { $, $$, errorText, busy, showErr, hideErr, qs, toast } from "../core/ui.js";
import { createProfile } from "../services/users.js";

initPage({ active: "auth" });

// Возврат на страницу, с которой пришли (только относительные ссылки — защита от open redirect)
const nextRaw = qs("next") || "index.html";
const next = /^[a-z0-9_-]+\.html/i.test(nextRaw) ? nextRaw : "index.html";
let registering = false;

// Уже вошли — сразу уходим
onSession((s) => { if (s.user && s.profile && !registering) location.replace(next); });

function setMode(mode) {
  ["login", "register", "reset"].forEach((m) => $(`#${m}-form`).classList.toggle("hidden", m !== mode));
  $$("#auth-tabs .tab").forEach((t) => t.classList.toggle("active", t.dataset.mode === mode));
  $("#auth-tabs").classList.toggle("hidden", mode === "reset");
  $$(".form-error").forEach(hideErr);
  setTimeout(() => $(`#${mode}-form input`)?.focus(), 30);
}
document.addEventListener("click", (e) => { const m = e.target.closest("[data-mode]")?.dataset.mode; if (m) { e.preventDefault(); setMode(m); } });
$("#forgot-link").onclick = () => { $("#f-email").value = $("#l-email").value; setMode("reset"); };
if (location.hash === "#register") setMode("register");

$("#login-form").onsubmit = (e) => {
  e.preventDefault();
  const box = $("#login-error"); hideErr(box);
  busy($("#login-btn"), async () => {
    try {
      // «Запомнить меня»: local — сессия переживает закрытие браузера, session — только до закрытия вкладки
      await setPersistence(auth, $("#l-remember").checked ? browserLocalPersistence : browserSessionPersistence);
      await signInWithEmailAndPassword(auth, $("#l-email").value.trim(), $("#l-pass").value);
      toast("👋 Вы вошли");
    } catch (err) { showErr(box, errorText(err)); }
  });
};

$("#register-form").onsubmit = (e) => {
  e.preventDefault();
  const box = $("#register-error"); hideErr(box);
  const name = $("#r-name").value.trim(), email = $("#r-email").value.trim();
  const pass = $("#r-pass").value, pass2 = $("#r-pass2").value;
  if (name.length < 2) return showErr(box, "Введите имя");
  if (pass.length < 6) return showErr(box, "Пароль должен быть не короче 6 символов");
  if (pass !== pass2) return showErr(box, "Пароли не совпадают");
  registering = true;
  busy($("#register-btn"), async () => {
    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, pass);
      await Promise.all([updateProfile(user, { displayName: name }), createProfile(user, name)]);
      toast("🎉 Аккаунт создан!");
      location.replace(next);
    } catch (err) { registering = false; showErr(box, errorText(err)); }
  });
};

$("#reset-form").onsubmit = (e) => {
  e.preventDefault();
  const box = $("#reset-error"), ok = $("#reset-ok"); hideErr(box); ok.classList.add("hidden");
  busy($("#reset-btn"), async () => {
    try {
      await sendPasswordResetEmail(auth, $("#f-email").value.trim());
      ok.textContent = "📧 Если такой email зарегистрирован, письмо уже отправлено. Проверьте и папку «Спам».";
      ok.classList.remove("hidden");
    } catch (err) { showErr(box, errorText(err)); }
  });
};
