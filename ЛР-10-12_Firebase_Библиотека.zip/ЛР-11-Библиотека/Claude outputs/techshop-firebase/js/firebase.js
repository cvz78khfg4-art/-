/**
 * Инициализация Firebase (модульный SDK v12, ES-модули через CDN).
 * Все остальные модули импортируют отсюда db/auth и нужные функции SDK.
 */
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
import {
  initializeFirestore, persistentLocalCache, persistentMultipleTabManager
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

export const app = initializeApp(firebaseConfig);

// Оптимизация: постоянный локальный кэш (IndexedDB) общий для всех вкладок —
// повторные чтения берутся из кэша, onSnapshot присылает только изменения.
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
});

export const auth = getAuth(app);

// Реэкспорт функций Firestore/Auth, чтобы версия SDK была указана в одном месте
export * from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
export {
  onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  signOut, sendPasswordResetEmail, updateProfile, setPersistence,
  browserLocalPersistence, browserSessionPersistence
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";
