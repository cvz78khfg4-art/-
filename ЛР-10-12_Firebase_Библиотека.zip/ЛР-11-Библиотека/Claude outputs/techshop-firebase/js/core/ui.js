/** Общие UI-утилиты: экранирование, форматирование, уведомления, модальные окна, тема. */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Экранирование данных из БД перед вставкой в HTML (защита от XSS) */
export const esc = (v) => String(v ?? "")
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

export const money = (v) => Math.round(Number(v) || 0).toLocaleString("ru-RU") + " ₸";

const toDate = (v) => (v?.toDate ? v.toDate() : v ? new Date(v) : null);
export const fmtDate = (v) => toDate(v)?.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" }) ?? "—";
export const fmtDateTime = (v) => toDate(v)?.toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) ?? "только что";

export const stars = (r) => {
  const n = Math.round(Number(r) || 0);
  return "★".repeat(n) + "☆".repeat(5 - n);
};

export const plural = (n, one, few, many) => {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
  return many;
};

/** Категории магазина: иконка и цвета градиента карточки */
export const CATEGORIES = {
  "Периферия":     { emoji: "🖱️", c1: "#e0e7ff", c2: "#c7d2fe" },
  "Аудио":         { emoji: "🎧", c1: "#fce7f3", c2: "#fbcfe8" },
  "Мониторы":      { emoji: "🖥️", c1: "#dbeafe", c2: "#bae6fd" },
  "Комплектующие": { emoji: "🧩", c1: "#dcfce7", c2: "#bbf7d0" },
  "Аксессуары":    { emoji: "🎒", c1: "#fef3c7", c2: "#fde68a" },
  "Смартфоны":     { emoji: "📱", c1: "#ede9fe", c2: "#ddd6fe" }
};
export const catStyle = (c) => CATEGORIES[c] || { emoji: "📦", c1: "#e5e7eb", c2: "#d1d5db" };

export const ORDER_STATUS = {
  new:       { text: "Новый",       cls: "pill-info" },
  confirmed: { text: "Подтверждён", cls: "pill-warn" },
  shipped:   { text: "Отправлен",   cls: "pill-warn" },
  done:      { text: "Доставлен",   cls: "pill-ok" },
  cancelled: { text: "Отменён",     cls: "pill-danger" }
};
export const statusPill = (s) => {
  const st = ORDER_STATUS[s] || { text: s, cls: "pill-muted" };
  return `<span class="pill ${st.cls}">${st.text}</span>`;
};

export function stockPill(stock) {
  if (stock <= 0) return '<span class="pill pill-danger">❌ Нет в наличии</span>';
  if (stock <= 5) return `<span class="pill pill-warn">⚠️ Осталось ${stock}</span>`;
  return '<span class="pill pill-ok">✅ В наличии</span>';
}

/** Русские тексты ошибок Firebase */
export function errorText(e) {
  const m = {
    "auth/invalid-email": "Некорректный email",
    "auth/missing-email": "Введите email",
    "auth/missing-password": "Введите пароль",
    "auth/email-already-in-use": "Этот email уже зарегистрирован",
    "auth/weak-password": "Пароль должен быть не короче 6 символов",
    "auth/invalid-credential": "Неверный email или пароль",
    "auth/invalid-login-credentials": "Неверный email или пароль",
    "auth/wrong-password": "Неверный email или пароль",
    "auth/user-not-found": "Пользователь не найден",
    "auth/too-many-requests": "Слишком много попыток, попробуйте позже",
    "auth/network-request-failed": "Нет соединения с интернетом",
    "auth/unauthorized-domain": "Домен сайта не добавлен в Authorized domains Firebase",
    "permission-denied": "Недостаточно прав (правила безопасности Firestore)",
    "failed-precondition": "Для этого запроса нужен индекс Firestore (ссылка на создание — в консоли браузера)",
    "unavailable": "Нет соединения с сервером"
  };
  return m[e?.code] || e?.message || String(e);
}

/** Всплывающее уведомление */
export function toast(text, isErr = false) {
  let box = $("#toasts");
  if (!box) { box = document.createElement("div"); box.id = "toasts"; box.className = "toasts"; document.body.appendChild(box); }
  const el = document.createElement("div");
  el.className = "toast" + (isErr ? " err" : "");
  el.textContent = text;
  box.appendChild(el);
  setTimeout(() => { el.style.transition = "opacity .3s"; el.style.opacity = "0"; setTimeout(() => el.remove(), 300); }, 2800);
}

export const showErr = (box, text) => { box.textContent = text; box.classList.remove("hidden"); };
export const hideErr = (box) => box?.classList.add("hidden");

/** Модальные окна: <div class="overlay" id="..."><div class="modal">...</div></div> */
export function openModal(id) {
  const m = document.getElementById(id);
  m.classList.add("open");
  $$(".form-error", m).forEach(hideErr);
  setTimeout(() => m.querySelector("input, textarea, select")?.focus(), 50);
}
export function closeModal(m) {
  if (typeof m === "string") m = document.getElementById(m);
  m.classList.remove("open");
  m.querySelector("form")?.reset();
}
document.addEventListener("click", (e) => {
  const o = e.target.closest(".overlay");
  if (o && (e.target === o || e.target.closest("[data-close]"))) closeModal(o);
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") $$(".overlay.open").forEach(closeModal);
});

/** Тема оформления (светлая/тёмная) */
export function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem("theme", theme); } catch (e) {}
}
export const currentTheme = () => document.documentElement.dataset.theme === "dark" ? "dark" : "light";

/** Блокировка кнопки на время запроса */
export async function busy(btn, fn) {
  btn.disabled = true;
  try { return await fn(); } finally { btn.disabled = false; }
}

/** Скелетоны карточек при загрузке */
export const skeletonCards = (n = 8) => Array.from({ length: n }, () => `
  <div class="skeleton"><div class="sk" style="aspect-ratio:4/3;border-radius:0"></div>
    <div style="padding:16px"><div class="sk" style="height:12px;width:40%"></div>
    <div class="sk" style="height:16px;width:80%;margin-top:10px"></div>
    <div class="sk" style="height:22px;width:50%;margin-top:18px"></div></div></div>`).join("");

export const qs = (name) => new URLSearchParams(location.search).get(name);
