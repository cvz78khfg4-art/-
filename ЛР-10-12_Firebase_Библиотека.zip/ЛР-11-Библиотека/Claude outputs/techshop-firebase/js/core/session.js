/**
 * Сессия пользователя: отслеживание входа (onAuthStateChanged), профиль и роль
 * из Firestore в реальном времени, общая шапка сайта и защита страниц по ролям.
 */
import { auth, db, doc, onSnapshot, onAuthStateChanged, signOut } from "../firebase.js";
import { $, esc, applyTheme, currentTheme, toast } from "./ui.js";
import { createProfile } from "../services/users.js";

const state = { user: null, profile: null, role: null, ready: false, cartCount: 0 };
const listeners = new Set();
let unsubProfile = null, unsubCart = null;

export const session = state;
export const isAdmin = () => state.role === "admin";

/** Подписка на изменения сессии (вход/выход/смена роли/профиля) */
export function onSession(cb) {
  listeners.add(cb);
  if (state.ready) cb(state);
  return () => listeners.delete(cb);
}
const emit = () => { renderHeader(); listeners.forEach((cb) => cb(state)); };

onAuthStateChanged(auth, (user) => {
  unsubProfile?.(); unsubCart?.();
  unsubProfile = unsubCart = null;
  state.user = user;
  state.profile = null;
  state.role = null;
  state.cartCount = 0;

  if (!user) { state.ready = true; emit(); return; }

  // Профиль: onSnapshot — роль, назначенная админом, применяется без перезагрузки
  unsubProfile = onSnapshot(doc(db, "users", user.uid), (snap) => {
    if (!snap.exists()) {
      // Сразу после регистрации документ создаётся чуть позже. Если профиля нет и
      // через 4 с (например, сбой при регистрации) — создаём его с ролью user.
      setTimeout(() => { if (!state.profile && state.user?.uid === user.uid) createProfile(user, user.displayName).catch(console.error); }, 4000);
      return;
    }
    state.profile = { id: snap.id, ...snap.data() };
    state.role = state.profile.role || "user";
    const theme = state.profile.settings?.theme;
    if (theme && theme !== currentTheme()) applyTheme(theme);
    state.ready = true;
    emit();
  }, (e) => { console.error("profile", e); state.ready = true; emit(); });

  // Счётчик корзины в шапке (активные действия — коллекция carts)
  unsubCart = onSnapshot(doc(db, "carts", user.uid), (snap) => {
    const items = snap.data()?.items || {};
    state.cartCount = Object.values(items).reduce((s, i) => s + (i.qty || 0), 0);
    renderHeader();
  }, (e) => console.error("cart", e));
});

/**
 * Инициализация страницы.
 * @param {{active?: string, requireAuth?: boolean, requireAdmin?: boolean}} opts
 * @returns {Promise<typeof state>} резолвится, когда известны пользователь и роль
 */
export function initPage(opts = {}) {
  renderHeader(opts.active);
  return new Promise((resolve) => {
    const off = onSession((s) => {
      if (opts.requireAuth && !s.user) {
        location.replace("auth.html?next=" + encodeURIComponent(location.pathname.split("/").pop() + location.search + location.hash));
        return;
      }
      if (opts.requireAdmin && s.role !== "admin") {
        if (s.user && !s.profile) return; // профиль ещё грузится
        document.querySelector("main").innerHTML = `<div class="empty"><div class="big">⛔</div><h2>Доступ запрещён</h2><p>Эта страница доступна только администраторам.</p><a class="btn btn-primary" href="index.html">В каталог</a></div>`;
        resolve(s); off(); return;
      }
      if (s.user && !s.profile) return; // ждём профиль
      resolve(s); off();
    });
  });
}

let activePage = "";
function renderHeader(active) {
  if (active) activePage = active;
  const host = $("#app-header");
  if (!host) return;
  const u = state.user, p = state.profile;
  const name = p?.displayName || u?.email || "";
  const letter = (name.trim()[0] || "?").toUpperCase();
  const link = (href, key, label) => `<a href="${href}" class="${activePage === key ? "active" : ""}">${label}</a>`;

  host.innerHTML = `
    <div class="container">
      <a class="logo" href="index.html"><span class="logo-mark">⚡</span><span>TechShop</span></a>
      <nav class="nav">
        ${link("index.html", "catalog", "🛍 <span class='hide-sm'>Каталог</span>")}
        ${link("cart.html", "cart", `🛒 <span class='hide-sm'>Корзина</span>${state.cartCount ? ` <span class="badge-count">${state.cartCount}</span>` : ""}`)}
        ${u ? link("profile.html", "profile", "👤 <span class='hide-sm'>Кабинет</span>") : ""}
        ${state.role === "admin" ? link("admin.html", "admin", "🛠 <span class='hide-sm'>Админка</span>") : ""}
      </nav>
      <div class="header-actions">
        <button class="btn btn-ghost btn-icon" id="theme-btn" title="Сменить тему">${currentTheme() === "dark" ? "☀️" : "🌙"}</button>
        ${u ? `
          <div class="menu-wrap" id="user-wrap">
            <button class="user-chip" id="user-chip"><span class="mini-avatar">${esc(letter)}</span><span class="hide-sm">${esc(name)}</span></button>
            <div class="menu hidden" id="user-menu">
              <div class="menu-head"><div>${esc(u.email)}</div><div>${state.role === "admin" ? "Администратор" : "Пользователь"}</div></div>
              <button data-href="profile.html">👤 Личный кабинет</button>
              <button data-href="profile.html#orders">📦 Мои заказы</button>
              <button data-href="cart.html">🛒 Корзина</button>
              ${state.role === "admin" ? `<button data-href="admin.html">🛠 Админ-панель</button>` : ""}
              <button id="logout-btn">🚪 Выйти</button>
            </div>
          </div>` : `<a class="btn btn-primary" href="auth.html">Войти</a>`}
      </div>
    </div>`;

  $("#theme-btn").onclick = () => { applyTheme(currentTheme() === "dark" ? "light" : "dark"); renderHeader(); };
  const chip = $("#user-chip");
  if (chip) {
    chip.onclick = (e) => { e.stopPropagation(); $("#user-menu").classList.toggle("hidden"); };
    $("#user-menu").onclick = (e) => { const h = e.target.closest("[data-href]")?.dataset.href; if (h) location.href = h; };
    $("#logout-btn").onclick = async () => { await signOut(auth); toast("Вы вышли из аккаунта"); location.href = "index.html"; };
  }
}
document.addEventListener("click", (e) => { if (!e.target.closest("#user-wrap")) $("#user-menu")?.classList.add("hidden"); });

// Применяем сохранённую тему как можно раньше
try {
  const t = localStorage.getItem("theme");
  applyTheme(t || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
} catch (e) {}
