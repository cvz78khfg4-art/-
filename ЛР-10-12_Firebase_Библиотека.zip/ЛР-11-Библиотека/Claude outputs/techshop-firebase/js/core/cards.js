/** Общая разметка карточки товара (каталог, похожие товары). */
import { esc, money, catStyle, stockPill, stars } from "./ui.js";

export function productCard(p, i = 0) {
  const s = catStyle(p.category);
  const icon = p.image || s.emoji;
  return `
    <a class="card" href="product.html?id=${encodeURIComponent(p.id)}" style="animation-delay:${Math.min(i, 12) * 30}ms">
      <div class="card-media" style="--c1:${s.c1};--c2:${s.c2}">
        <span class="stock-badge">${stockPill(p.stock)}</span>
        ${esc(icon)}
      </div>
      <div class="card-body">
        <span class="card-cat">${esc(p.category)}</span>
        <h3 class="card-title">${esc(p.name)}</h3>
        <span class="rating"><span class="stars">${stars(p.rating)}</span> ${p.ratingCount ? `${p.rating} · ${p.ratingCount}` : "нет отзывов"}</span>
        ${p.description ? `<p class="card-desc">${esc(p.description)}</p>` : ""}
        <div class="card-foot">
          <span class="price">${money(p.price)}${p.oldPrice > p.price ? `<span class="old-price">${money(p.oldPrice)}</span>` : ""}</span>
        </div>
      </div>
    </a>`;
}
