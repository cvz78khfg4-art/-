/** Пользователи (коллекция users): профиль, настройки, роли. */
import {
  db, collection, doc, query, orderBy, limit, startAfter, getDocs, setDoc, updateDoc,
  serverTimestamp, getCountFromServer
} from "../firebase.js";

const col = collection(db, "users");

/** Профиль при регистрации. Роль всегда "user" — правила не дадут записать другую */
export const createProfile = (user, displayName) =>
  setDoc(doc(db, "users", user.uid), {
    email: user.email,
    displayName: displayName || "",
    phone: "", address: "",
    role: "user",
    settings: { theme: "light", newsletter: false },
    createdAt: serverTimestamp(), updatedAt: serverTimestamp()
  });

export const updateMyProfile = (uid, data) =>
  updateDoc(doc(db, "users", uid), { ...data, updatedAt: serverTimestamp() });

/** Список пользователей для админа (курсорная пагинация) */
export async function usersPage(cursor = null, size = 20) {
  const parts = [orderBy("createdAt", "desc")];
  if (cursor) parts.push(startAfter(cursor));
  parts.push(limit(size));
  const snap = await getDocs(query(col, ...parts));
  return { items: snap.docs.map((d) => ({ id: d.id, ...d.data() })), cursor: snap.docs.at(-1) || null, hasMore: snap.size === size };
}

/** Назначение прав доступа (только админ — проверяется правилами) */
export const setRole = (uid, role) => updateDoc(doc(db, "users", uid), { role, updatedAt: serverTimestamp() });

export const countUsers = async () => (await getCountFromServer(col)).data().count;
