/**
 * Отзывы (коллекция reviews). ID документа = productId_uid — один отзыв
 * пользователя на товар. Средний рейтинг хранится прямо в товаре
 * (ratingSum/ratingCount/rating) — денормализация, чтобы каталог мог
 * сортировать по рейтингу без чтения всех отзывов. Агрегаты обновляются
 * транзакцией вместе с отзывом; правила проверяют корректность дельты.
 */
import {
  db, collection, doc, query, where, orderBy, limit, onSnapshot, runTransaction,
  serverTimestamp, getCountFromServer
} from "../firebase.js";

const col = collection(db, "reviews");
export const reviewId = (productId, uid) => `${productId}_${uid}`;

/** Отзывы товара в реальном времени, с подгрузкой — индекс (productId, createdAt DESC) */
export const watchProductReviews = (productId, count, cb, onError) =>
  onSnapshot(query(col, where("productId", "==", productId), orderBy("createdAt", "desc"), limit(count + 1)), (snap) => {
    const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    cb({ items: items.slice(0, count), hasMore: items.length > count });
  }, onError);

/** Мои отзывы — индекс (userId, createdAt DESC) */
export const watchMyReviews = (uid, cb, onError) =>
  onSnapshot(query(col, where("userId", "==", uid), orderBy("createdAt", "desc"), limit(50)),
    (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), onError);

/** Последние отзывы для модерации (админ) */
export const watchAllReviews = (count, cb, onError) =>
  onSnapshot(query(col, orderBy("createdAt", "desc"), limit(count)),
    (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), onError);

const ratingOf = (sum, cnt) => (cnt ? Math.round((sum / cnt) * 10) / 10 : 0);

/** Создать или изменить свой отзыв + пересчитать рейтинг товара (транзакция) */
export async function saveReview(user, profile, product, { rating, text }) {
  const rRef = doc(db, "reviews", reviewId(product.id, user.uid));
  const pRef = doc(db, "products", product.id);
  await runTransaction(db, async (tx) => {
    const [rSnap, pSnap] = await Promise.all([tx.get(rRef), tx.get(pRef)]);
    if (!pSnap.exists()) throw new Error("Товар не найден");
    const p = pSnap.data();
    const old = rSnap.exists() ? rSnap.data().rating : 0;
    const ratingSum = (p.ratingSum || 0) + rating - old;
    const ratingCount = (p.ratingCount || 0) + (rSnap.exists() ? 0 : 1);
    if (rSnap.exists()) {
      tx.update(rRef, { rating, text, updatedAt: serverTimestamp() });
    } else {
      tx.set(rRef, {
        productId: product.id, productName: product.name, userId: user.uid,
        userName: profile?.displayName || user.email.split("@")[0],
        rating, text, createdAt: serverTimestamp(), updatedAt: serverTimestamp()
      });
    }
    tx.update(pRef, { ratingSum, ratingCount, rating: ratingOf(ratingSum, ratingCount) });
  });
}

/** Удалить отзыв (автор или админ-модератор) + пересчитать рейтинг */
export async function deleteReview(id) {
  const rRef = doc(db, "reviews", id);
  await runTransaction(db, async (tx) => {
    const rSnap = await tx.get(rRef);
    if (!rSnap.exists()) return;
    const r = rSnap.data();
    const pRef = doc(db, "products", r.productId);
    const pSnap = await tx.get(pRef);
    tx.delete(rRef);
    if (pSnap.exists()) {
      const p = pSnap.data();
      const ratingSum = Math.max(0, (p.ratingSum || 0) - r.rating);
      const ratingCount = Math.max(0, (p.ratingCount || 0) - 1);
      tx.update(pRef, { ratingSum, ratingCount, rating: ratingOf(ratingSum, ratingCount) });
    }
  });
}

export const countReviews = async () => (await getCountFromServer(col)).data().count;
