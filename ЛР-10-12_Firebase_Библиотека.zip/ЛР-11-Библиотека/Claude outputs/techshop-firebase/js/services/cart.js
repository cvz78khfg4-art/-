/**
 * Корзина — «активные действия» (коллекция carts, документ = uid пользователя).
 * Оформление заказа — транзакция: проверка остатков, создание заказа (orders),
 * списание остатков товаров и очистка корзины выполняются атомарно.
 */
import {
  db, doc, collection, onSnapshot, setDoc, updateDoc, deleteField, deleteDoc,
  runTransaction, serverTimestamp
} from "../firebase.js";

const cartRef = (uid) => doc(db, "carts", uid);
export const MAX_QTY = 20;

export const watchCart = (uid, cb, onError) =>
  onSnapshot(cartRef(uid), (snap) => cb(snap.data()?.items || {}), onError);

/**
 * Добавить товар. В корзине дублируем name/price/image — чтобы страница
 * корзины отрисовывалась без чтения каждого товара (денормализация).
 */
export async function addToCart(uid, product, qty = 1) {
  const ref = cartRef(uid);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    const items = snap.data()?.items || {};
    const current = items[product.id]?.qty || 0;
    const next = Math.min(current + qty, product.stock, MAX_QTY);
    if (next <= current) throw Object.assign(new Error(`Доступно не больше ${Math.min(product.stock, MAX_QTY)} шт.`), { code: "limit" });
    items[product.id] = { qty: next, name: product.name, price: product.price, image: product.image || "", category: product.category };
    tx.set(ref, { items, updatedAt: serverTimestamp() });
  });
}

export const setQty = (uid, productId, qty) =>
  updateDoc(cartRef(uid), { [`items.${productId}.qty`]: qty, updatedAt: serverTimestamp() });

export const removeFromCart = (uid, productId) =>
  updateDoc(cartRef(uid), { [`items.${productId}`]: deleteField(), updatedAt: serverTimestamp() });

export const clearCart = (uid) => deleteDoc(cartRef(uid));

/**
 * Оформление заказа (транзакция).
 * Правила безопасности разрешают пользователю менять у товара только поле stock
 * (и lastOrderId), причём ровно на количество из создаваемого в этой же
 * транзакции заказа — подделать остаток нельзя.
 */
export async function checkout(user, profile, form) {
  const ref = cartRef(user.uid);
  const orderRef = doc(collection(db, "orders"));

  return runTransaction(db, async (tx) => {
    const cartSnap = await tx.get(ref);
    const cart = cartSnap.data()?.items || {};
    const ids = Object.keys(cart);
    if (!ids.length) throw new Error("Корзина пуста");

    // 1) читаем актуальные товары и проверяем остатки
    const prodSnaps = await Promise.all(ids.map((id) => tx.get(doc(db, "products", id))));
    const items = {};
    let total = 0, count = 0;
    prodSnaps.forEach((s, i) => {
      const id = ids[i], want = cart[id].qty;
      if (!s.exists()) throw new Error(`Товар «${cart[id].name}» больше не продаётся — удалите его из корзины`);
      const p = s.data();
      if (p.stock < want) throw new Error(`«${p.name}»: на складе только ${p.stock} шт.`);
      // фиксируем цену на момент покупки (как price_at_purchase в ЛР-2)
      items[id] = { name: p.name, price: p.price, qty: want, image: p.image || "", category: p.category };
      total += p.price * want;
      count += want;
    });

    // 2) создаём заказ — он попадёт в «Историю» (личный кабинет)
    tx.set(orderRef, {
      userId: user.uid,
      userEmail: user.email,
      userName: profile?.displayName || "",
      items, itemsCount: count, total,
      phone: form.phone, address: form.address, comment: form.comment || "",
      status: "new",
      createdAt: serverTimestamp(), updatedAt: serverTimestamp()
    });

    // 3) списываем остатки
    prodSnaps.forEach((s, i) =>
      tx.update(s.ref, { stock: s.data().stock - cart[ids[i]].qty, lastOrderId: orderRef.id }));

    // 4) корзина (активные действия) очищается — данные переехали в историю
    tx.delete(ref);
    return orderRef.id;
  });
}

/** Сохранить контакты в профиль для следующих заказов */
export const rememberContacts = (uid, { phone, address }) =>
  setDoc(doc(db, "users", uid), { phone, address, updatedAt: serverTimestamp() }, { merge: true });
