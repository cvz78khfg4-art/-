/**
 * Поиск в Firestore. В Firestore нет полнотекстового поиска, поэтому при
 * сохранении товара строим массив keywords (слова и их префиксы) и ищем
 * запросом where("keywords", "array-contains", слово) — это реальный запрос
 * к базе, который работает с индексами и пагинацией.
 */

export const normalize = (s) => String(s || "").toLowerCase().replace(/ё/g, "е").replace(/[^a-zа-я0-9]+/gi, " ").trim();

const words = (s) => normalize(s).split(" ").filter((w) => w.length >= 2);

/** Префиксы слова от 2 символов: «мышь» → «мы», «мыш», «мышь» */
const prefixes = (w) => Array.from({ length: Math.min(w.length, 15) - 1 }, (_, i) => w.slice(0, i + 2));

/**
 * Ключевые слова товара: префиксы слов названия/категории/тегов
 * и целые слова описания (чтобы искать «по названию/описанию»).
 */
export function buildKeywords({ name = "", category = "", tags = [], description = "" }) {
  const set = new Set();
  [...words(name), ...words(category), ...tags.flatMap(words)].forEach((w) => prefixes(w).forEach((p) => set.add(p)));
  words(description).forEach((w) => set.add(w));
  return [...set].slice(0, 300);
}

/** Слово запроса для array-contains: самое длинное слово из введённой строки */
export function searchToken(input) {
  const ws = words(input);
  if (!ws.length) return "";
  return ws.sort((a, b) => b.length - a.length)[0].slice(0, 15);
}

/** Дополнительная проверка остальных слов запроса на клиенте (если их несколько) */
export function matchesAll(product, input) {
  const hay = normalize([product.name, product.category, (product.tags || []).join(" "), product.description].join(" "));
  return words(input).every((w) => hay.includes(w));
}
