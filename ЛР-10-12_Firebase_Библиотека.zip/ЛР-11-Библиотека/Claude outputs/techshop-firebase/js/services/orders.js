/**
 * Заказы (коллекция orders) — история действий пользователя.
 * Статусы обновляются в реальном времени (onSnapshot).
 */
import {
  db, collection, doc, query, where, orderBy, limit, onSnapshot, runTransaction,
  serverTimestamp, increment, getCountFromServer, getAggregateFromServer, sum
} from "../firebase.js";

const col = collection(db, "orders");

/** Мои заказы — индекс (userId ASC, createdAt DESC) */
export const watchMyOrders = (uid, count, cb, onError) =>
  onSnapshot(query(col, where("userId", "==", uid), orderBy("createdAt", "desc"), limit(count + 1)), (snap) => {
    const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    cb({ items: items.slice(0, count), hasMore: items.length > count });
  }, onError);

/** Все заказы (админ), фильтр по статусу — индекс (status ASC, createdAt DESC) */
export function watchAllOrders(status, count, cb, onError) {
  const parts = status && status !== "all" ? [where("status", "==", status)] : [];
  return onSnapshot(query(col, ...parts, orderBy("createdAt", "desc"), limit(count + 1)), (snap) => {
    const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    cb({ items: items.slice(0, count), hasMore: items.length > count });
  }, onError);
}

/**
 * Смена статуса. Отмена возвращает товары на склад в той же транзакции.
 * Пользователь может отменить только свой заказ в статусе «Новый».
 */
export async function setOrderStatus(orderId, status) {
  const ref = doc(db, "orders", orderId);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new Error("Заказ не найден");
    const order = snap.data();
    if (order.status === "cancelled") throw new Error("Заказ уже отменён");
    // в транзакции все чтения выполняются до записей
    const entries = Object.entries(order.items || {});
    const prods = status === "cancelled" ? await Promise.all(entries.map(([pid]) => tx.get(doc(db, "products", pid)))) : [];
    tx.update(ref, { status, updatedAt: serverTimestamp() });
    prods.forEach((p, i) => {
      if (p.exists()) tx.update(p.ref, { stock: increment(entries[i][1].qty), lastOrderId: orderId });
    });
  });
}

/** Статистика для админки: агрегирующие запросы считаются на сервере (без загрузки документов) */
export async function orderStats() {
  const [all, fresh, revenue] = await Promise.all([
    getCountFromServer(col),
    getCountFromServer(query(col, where("status", "==", "new"))),
    getAggregateFromServer(query(col, where("status", "==", "done")), { total: sum("total") })
  ]);
  return { orders: all.data().count, newOrders: fresh.data().count, revenue: revenue.data().total || 0 };
}
