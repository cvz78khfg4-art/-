/**
 * Товары (коллекция products): каталог с пагинацией и реальным временем,
 * детальная карточка, похожие товары (курсорная пагинация), CRUD для админа.
 */
import {
  db, collection, doc, query, where, orderBy, limit, startAfter, onSnapshot, getDocs,
  addDoc, updateDoc, deleteDoc, serverTimestamp, writeBatch, getCountFromServer
} from "../firebase.js";
import { buildKeywords, searchToken, normalize } from "./search.js";

const col = collection(db, "products");

export const SORTS = {
  new:          { field: "createdAt", dir: "desc", label: "Сначала новые" },
  "price-asc":  { field: "price",     dir: "asc",  label: "Сначала дешёвые" },
  "price-desc": { field: "price",     dir: "desc", label: "Сначала дорогие" },
  rating:       { field: "rating",    dir: "desc", label: "По рейтингу" }
};

/**
 * Каталог в реальном времени с пагинацией «Показать ещё».
 * Каждое нажатие увеличивает limit на pageSize, подписка onSnapshot
 * пересоздаётся — новые/изменённые админом товары появляются без перезагрузки.
 * Запрашиваем на 1 документ больше, чтобы понять, есть ли следующая страница.
 */
export function watchCatalog({ category = "all", search = "", sort = "new", count = 12 }, cb, onError) {
  const s = SORTS[sort] || SORTS.new;
  const parts = [];
  if (category !== "all") parts.push(where("category", "==", category));
  const token = searchToken(search);
  if (token) parts.push(where("keywords", "array-contains", token));
  parts.push(orderBy(s.field, s.dir), limit(count + 1));

  return onSnapshot(query(col, ...parts), (snap) => {
    const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    cb({ items: items.slice(0, count), hasMore: items.length > count, fromCache: snap.metadata.fromCache });
  }, onError);
}

/** Один товар в реальном времени (остаток, цена, рейтинг) */
export const watchProduct = (id, cb, onError) =>
  onSnapshot(doc(db, "products", id), (snap) => cb(snap.exists() ? { id: snap.id, ...snap.data() } : null), onError);

/** Похожие товары той же категории — курсорная пагинация через startAfter */
export async function similarPage(category, cursor = null, size = 4) {
  const parts = [where("category", "==", category), orderBy("rating", "desc"), limit(size)];
  if (cursor) parts.splice(2, 0, startAfter(cursor));
  const snap = await getDocs(query(col, ...parts));
  return { items: snap.docs.map((d) => ({ id: d.id, ...d.data() })), cursor: snap.docs.at(-1) || null, hasMore: snap.size === size };
}

/** Категории для фильтра (берутся из справочника, без лишнего чтения всей коллекции) */
export { CATEGORIES } from "../core/ui.js";

/* ===================== Админ ===================== */

/** Страница таблицы товаров для админа: поиск по началу названия + курсор */
export async function adminProductsPage({ term = "", cursor = null, size = 15 }) {
  const t = normalize(term);
  const parts = t
    ? [where("nameLower", ">=", t), where("nameLower", "<=", t + ""), orderBy("nameLower")]
    : [orderBy("createdAt", "desc")];
  if (cursor) parts.push(startAfter(cursor));
  parts.push(limit(size));
  const snap = await getDocs(query(col, ...parts));
  return { items: snap.docs.map((d) => ({ id: d.id, ...d.data() })), cursor: snap.docs.at(-1) || null, hasMore: snap.size === size };
}

/** Подготовка документа товара: служебные поля для поиска и сортировки */
function prepare(data) {
  const tags = (data.tags || []).map((t) => t.trim()).filter(Boolean).slice(0, 10);
  return {
    name: data.name.trim(),
    nameLower: normalize(data.name),
    description: (data.description || "").trim(),
    category: data.category,
    tags,
    price: Math.round(Number(data.price)),
    oldPrice: data.oldPrice ? Math.round(Number(data.oldPrice)) : null,
    stock: Number(data.stock),
    image: (data.image || "").trim(),
    brand: (data.brand || "").trim(),
    keywords: buildKeywords({ ...data, tags }),
    updatedAt: serverTimestamp()
  };
}

export const createProduct = (data) =>
  addDoc(col, { ...prepare(data), rating: 0, ratingSum: 0, ratingCount: 0, createdAt: serverTimestamp() });
export const updateProduct = (id, data) => updateDoc(doc(db, "products", id), prepare(data));
export const patchProduct = (id, patch) => updateDoc(doc(db, "products", id), { ...patch, updatedAt: serverTimestamp() });
export const deleteProduct = (id) => deleteDoc(doc(db, "products", id));
export const countProducts = async () => (await getCountFromServer(col)).data().count;

/** Демо-данные: пакетная запись (writeBatch) — одна операция вместо 30 */
export async function seedProducts(list) {
  const batch = writeBatch(db);
  list.forEach((p, i) => {
    const ref = doc(col);
    batch.set(ref, {
      ...prepare(p), rating: 0, ratingSum: 0, ratingCount: 0,
      // разные даты, чтобы сортировка «Сначала новые» была наглядной
      createdAt: new Date(Date.now() - i * 3600_000)
    });
  });
  await batch.commit();
}
