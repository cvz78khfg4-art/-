import express from "express";
import {
  getProducts,
  getProductById,
  getProductOrders,
  createProduct,
  updateProduct,
  deleteProduct
} from "../controllers/productController.js";
import { validateCreateProduct } from "../middleware/validateCreateProduct.js";
import { validateUpdateProduct } from "../middleware/validateUpdateProduct.js";

const router = express.Router();

router.get("/", getProducts);
router.get("/:id", getProductById);

// Заказы, содержащие товар (relation filter some)
router.get("/:id/orders", getProductOrders);

router.post(
  "/",
  validateCreateProduct,
  createProduct
);

router.patch(
  "/:id",
  validateUpdateProduct,
  updateProduct
);

router.delete("/:id", deleteProduct);

export default router;
