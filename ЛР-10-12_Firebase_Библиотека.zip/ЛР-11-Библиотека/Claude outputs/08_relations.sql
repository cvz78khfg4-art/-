-- ЛР-4. Таблицы users, user_profiles, orders, order_items и тестовые данные.
--   psql -h localhost -U shop_user -d shop_db -f sql/08_relations.sql
-- Используются существующие categories и products (ЛР-3).
-- Скрипт рассчитан на «чистый» запуск: users получат id 1–3, orders — id 1–4,
-- товары Keyboard/Mouse/Monitor имеют id 1–3. При других id подставьте фактические.

\set ON_ERROR_STOP on

BEGIN;

-- 1. Существующие таблицы (Category 1 → N Products)
SELECT * FROM categories ORDER BY id;
SELECT * FROM products ORDER BY id;

-- 2. Пользователи
CREATE TABLE users (
  id INTEGER
    GENERATED ALWAYS AS IDENTITY
    PRIMARY KEY,
  name VARCHAR(100)
    NOT NULL,
  email VARCHAR(150)
    NOT NULL
    UNIQUE
);

-- 3.
INSERT INTO users
  (name, email)
VALUES
  ('Anna', 'anna@example.com'),
  ('Ivan', 'ivan@example.com'),
  ('Maria', 'maria@example.com');

SELECT *
FROM users
ORDER BY id;

-- Часть 1. Связь 1:1
-- 4. user_id одновременно PRIMARY KEY и FOREIGN KEY
CREATE TABLE user_profiles (
  user_id INTEGER
    PRIMARY KEY
    REFERENCES users(id),
  phone VARCHAR(30),
  address VARCHAR(250)
);

-- 5. Профиль Anna (id = 1)
INSERT INTO user_profiles
(
  user_id,
  phone,
  address
)
VALUES
(
  1,
  '+7 700 111 22 33',
  'Almaty'
);

-- Часть 2. Связь 1:N
-- 8.
CREATE TABLE orders (
  id INTEGER
    GENERATED ALWAYS AS IDENTITY
    PRIMARY KEY,
  user_id INTEGER
    NOT NULL
    REFERENCES users(id),
  status VARCHAR(30)
    NOT NULL
    DEFAULT 'new',
  created_at TIMESTAMPTZ
    NOT NULL
    DEFAULT CURRENT_TIMESTAMP
);

-- 9. Несколько заказов одного пользователя
INSERT INTO orders
  (user_id, status)
VALUES
  (1, 'new'),
  (1, 'paid'),
  (1, 'delivered');

-- 10. Заказ другого пользователя
INSERT INTO orders
  (user_id, status)
VALUES
  (2, 'new');

-- Часть 4. Связь M:N
-- 16. Промежуточная таблица с составным первичным ключом
CREATE TABLE order_items (
  order_id INTEGER
    NOT NULL
    REFERENCES orders(id),
  product_id INTEGER
    NOT NULL
    REFERENCES products(id),
  quantity INTEGER
    NOT NULL
    CHECK (quantity > 0),
  price INTEGER
    NOT NULL
    CHECK (price > 0),
  PRIMARY KEY (
    order_id,
    product_id
  )
);

-- 20. Товары в заказ 1
INSERT INTO order_items
(
  order_id,
  product_id,
  quantity,
  price
)
VALUES
(
  1,
  1,
  1,
  15000
),
(
  1,
  2,
  2,
  8000
),
(
  1,
  3,
  1,
  85000
);

-- 21. Тот же товар в другом заказе (вторая сторона M:N)
INSERT INTO order_items
(
  order_id,
  product_id,
  quantity,
  price
)
VALUES
(
  2,
  1,
  1,
  15000
);

COMMIT;

-- 22. Промежуточная таблица
SELECT *
FROM order_items
ORDER BY order_id, product_id;
